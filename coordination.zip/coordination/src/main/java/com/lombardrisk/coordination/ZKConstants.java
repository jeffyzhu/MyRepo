package com.lombardrisk.coordination;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class ZKConstants {
    private static final Logger LOG = LoggerFactory.getLogger(ZKConstants.class);
    public static final String ZK_BASE_PATH = "/com.lombardrisk.colline";
    public static final String WORKERS_PATH = ZK_BASE_PATH + "/workers";
    public static final String ASSIGN_PATH = ZK_BASE_PATH + "/assign";
    public static final String TASKS_PATH = ZK_BASE_PATH + "/tasks";
    public static final String STATUS_PATH = ZK_BASE_PATH + "/status";
    public static final String MASTER_PATH = ZK_BASE_PATH + "/master";
    public static final String BLOCKED_TASKS_PATH = ZK_BASE_PATH + "/blockedTasks";
    public static final String COMMAND_PAUSE_PATH = ZK_BASE_PATH + "/command/pause";
    public static final String COMMAND_CANCEL_PATH = ZK_BASE_PATH + "/command/cancel";
    public static final String PAUSED_TASKS_PATH = ZK_BASE_PATH + "/pausedTasks";

    private static String hostName = "";

    static {
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    public static String getHostName() {
        return hostName;
    }

    public enum TaskExecutionStatus {
        STARTED,
        COMPLETED,
        FAILED,
        INTERRUPTED,
        CANCELED,
        PAUSED,
        BLOCKED;

        public boolean isDone() {
            return COMPLETED == this || FAILED == this || INTERRUPTED == this;
        }

        public boolean isEnd() {
            return isDone() || CANCELED == this || PAUSED == this;
        }
    }
}
