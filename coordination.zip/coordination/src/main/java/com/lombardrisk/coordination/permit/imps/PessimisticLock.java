package com.lombardrisk.coordination.permit.imps;

import com.google.common.base.Charsets;
import com.lombardrisk.common.util.LogUtil;
import com.lombardrisk.coordination.CuratorClientFactory;
import com.lombardrisk.coordination.permit.api.PessimisticPermit;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.locks.InterProcessLock;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock;
import org.apache.curator.framework.recipes.locks.LockInternals;
import org.apache.curator.framework.recipes.locks.StandardLockInternalsDriver;
import org.apache.curator.utils.CloseableUtils;
import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.concurrent.TimeUnit;

public class PessimisticLock {
    private static final Logger LOG = LoggerFactory.getLogger(PessimisticLock.class);

    private static class InternalInterProcessLock implements InterProcessLock {
        private static final String READ_LOCK_NAME = "__READ__";
        private static final String WRITE_LOCK_NAME = "__WRIT__";

        private InterProcessMutex lock;
        private final String applicant;
        private CuratorFramework client;
        private String basePath;
        static final StandardLockInternalsDriver SORTER = new StandardLockInternalsDriver() {
            @Override
            public final String fixForSorting(String str, String lockName) {
                str = super.fixForSorting(str, READ_LOCK_NAME);
                str = super.fixForSorting(str, WRITE_LOCK_NAME);
                return str;
            }
        };

        public InternalInterProcessLock(CuratorFramework client, String basePath, String applicant, PessimisticPermitType.Mode mode) {
            this.client = client;
            this.basePath = basePath;
            this.applicant = applicant;
            byte[] bytes = this.applicant == null ? null : this.applicant.getBytes(Charsets.UTF_8);
            InterProcessReadWriteLock readWriteLock = new InterProcessReadWriteLock(client, basePath, bytes);
            if (PessimisticPermitType.Mode.READ == mode) {
                lock = readWriteLock.readLock();
            } else {
                lock = readWriteLock.writeLock();
            }
        }

        public Collection<String> getParticipantNodes() throws Exception {
            return LockInternals.getParticipantNodes(client, basePath, "", SORTER);
        }

        @Override
        public void acquire() throws Exception {
            lock.acquire();
        }

        @Override
        public boolean acquire(long time, TimeUnit unit) throws Exception {
            return lock.acquire(time, unit);
        }

        @Override
        public void release() throws Exception {
            lock.release();
        }

        @Override
        public boolean isAcquiredInThisProcess() {
            return lock.isAcquiredInThisProcess();
        }
    }

    private final CuratorFramework client;
    private final InternalInterProcessLock internalLock;
    private final String lockPath;

    private PessimisticLock(String path, String applicant, PessimisticPermitType.Mode mode) {
        this.client = CuratorClientFactory.create();
        client.start();
        this.internalLock = new InternalInterProcessLock(client, path, applicant, mode);
        this.lockPath = path;
    }

    public PessimisticLock(String path, String applicant) {
        this.client = CuratorClientFactory.create();
        client.start();
        this.internalLock = new InternalInterProcessLock(client, path, applicant, PessimisticPermitType.Mode.WRITE);
        this.lockPath = path;
    }

    public PessimisticLock(PessimisticPermitType type, String applicant) {
        this(type.getLockPath(), applicant, type.getMode());
    }

    /**
     * Acquire the mutex - blocking until it's available. Each call to acquire must be balanced by a call
     * to {@link PessimisticPermitImpl#release()}
     *
     * @return Lock {@link PessimisticPermitImpl}
     */
    public PessimisticPermit acquireLock() {
        return this.acquireLock(0, TimeUnit.SECONDS);
    }

    /**
     * Acquire the mutex - blocks until it's available or the given time expires.Note: the same thread
     * can call acquire re-entrantly. Each call to acquire must be balanced by a call
     * to {@link PessimisticPermitImpl#release()}
     *
     * @param time time to wait
     * @param unit time unit
     * @return Lock {@link PessimisticPermitImpl}
     */
    public PessimisticPermit acquireLock(long time, TimeUnit unit) {
        LogUtil.safeDebug(LOG, "acquire lock for path: " + lockPath);
        PessimisticPermitImpl pessimisticPermitImpl = new PessimisticPermitImpl(lockPath, this);
        try {
            boolean acquired = internalLock.acquire(time, unit);
            pessimisticPermitImpl.setAcquired(acquired);
            if (acquired) {
                pessimisticPermitImpl.setOwner(internalLock.applicant);
            } else {
                ParticipantNodes pNodes = getParticipantNodes(internalLock);
                if (pNodes.isNoNode()) {
                    return acquireLock(time, unit); // lock may already be released, acquire it again
                }
                Collection<String> participantNodes = pNodes.getParticipantNodes();
                if (participantNodes == null || participantNodes.isEmpty()) {
                    return acquireLock(time, unit); // lock may already be released, acquire it again
                } else {
                    String ownerPath = participantNodes.iterator().next();// first participant should be the owner
                    NodeData nodeData = getNodeData(client, ownerPath);
                    if (nodeData.isNoNode()) {
                        return acquireLock(time, unit); // lock may already be released, acquire it again
                    }
                    String owner = new String(nodeData.getBytes(), Charsets.UTF_8);
                    pessimisticPermitImpl.setOwner(owner);
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            pessimisticPermitImpl.setAcquired(false);
        }
        LogUtil.safeDebug(LOG, "lock for the acquire: " + pessimisticPermitImpl);
        return pessimisticPermitImpl;
    }

    private static class NodeData {
        private final boolean noNode;
        private final byte[] bytes;

        public NodeData(final boolean noNode, final byte[] bytes) {
            this.noNode = noNode;
            this.bytes = bytes;
        }

        public boolean isNoNode() {
            return noNode;
        }

        public byte[] getBytes() {
            return bytes;
        }
    }

    private NodeData getNodeData(CuratorFramework client, String nodePath) throws Exception {
        boolean noNode = false;
        byte[] bytes = null;
        try {
            bytes = client.getData().forPath(nodePath);
            LogUtil.safeDebug(LOG, "Get data for path: " + nodePath);
        } catch (KeeperException.NoNodeException e) {
            LOG.debug(e.getMessage(), e);
            noNode = true;
        }
        return new NodeData(noNode, bytes);
    }

    private static class ParticipantNodes {
        private final boolean noNode;
        private final Collection<String> participantNodes;

        public ParticipantNodes(final boolean noNode, final Collection<String> participantNodes) {
            this.noNode = noNode;
            this.participantNodes = participantNodes;
        }

        public boolean isNoNode() {
            return noNode;
        }

        public Collection<String> getParticipantNodes() {
            return participantNodes;
        }
    }

    private ParticipantNodes getParticipantNodes(InternalInterProcessLock internalLock) throws Exception {
        boolean noNode = false;
        Collection<String> participantNodes = null;
        try {
            participantNodes = internalLock.getParticipantNodes();
            LogUtil.safeDebug(LOG, "getParticipantNodes for path: " + lockPath);
        } catch (KeeperException.NoNodeException e) {
            LOG.debug(e.getMessage(), e);
            noNode = true;
        }
        return new ParticipantNodes(noNode, participantNodes);
    }

    /**
     * Query whether the lock is locked
     *
     * @return whether the lock acquired by someone
     */
    public PessimisticPermit queryLock() {
        LogUtil.safeDebug(LOG, "query lock for path: " + lockPath);
        PessimisticPermitImpl pessimisticPermitImpl = new PessimisticPermitImpl(lockPath, this);
        boolean locked = internalLock.isAcquiredInThisProcess();
        if (!locked) {
            PessimisticPermit state = acquireLock();
            locked = !state.isAcquired();
            if (state.isAcquired()) {
                release(false);
            } else {
                pessimisticPermitImpl.setOwner(state.getOwner());
            }
        } else {
            pessimisticPermitImpl.setOwner(internalLock.applicant);
        }
        pessimisticPermitImpl.setAcquired(locked);
        LogUtil.safeDebug(LOG, "lock for the query : " + pessimisticPermitImpl);
        return pessimisticPermitImpl;
    }

    /**
     * Perform one release of the lock.
     */
    public void release() {
        release(true);
    }

    /**
     * Perform one release of the lock.
     *
     * @param closeClient closeClient
     */
    private void release(final boolean closeClient) {
        LogUtil.safeDebug(LOG, "release lock for path: " + lockPath);
        try {
            if (internalLock.isAcquiredInThisProcess()) {
                internalLock.release();
                clean();
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }

        if (closeClient) {
            try {
                CloseableUtils.closeQuietly(client);
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
        }
    }

    private void clean() throws Exception {
        try {
            client.delete().guaranteed().forPath(lockPath);
            LogUtil.safeDebug(LOG, "Delete for path: " + lockPath);
        } catch (KeeperException.BadVersionException | KeeperException.NotEmptyException | KeeperException.NoNodeException ignore) {
            // ignore BadVersionException - another thread/process got the lock
            // ignore NotEmptyException - other threads/processes are waiting
            LOG.debug(ignore.getMessage(), ignore);
        }
    }
}
