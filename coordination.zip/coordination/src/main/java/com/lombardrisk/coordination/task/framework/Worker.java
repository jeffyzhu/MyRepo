package com.lombardrisk.coordination.task.framework;

import com.google.common.collect.Lists;
import com.lombardrisk.coordination.CuratorClientFactory;
import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.ZKConstants.TaskExecutionStatus;
import com.lombardrisk.coordination.permit.api.PessimisticPermit;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import com.lombardrisk.coordination.permit.imps.PessimisticLock;
import com.lombardrisk.coordination.task.api.BackgroundTask;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.zookeeper.CreateMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PreDestroy;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class Worker {

    private static final Logger LOG = LoggerFactory.getLogger(Worker.class);
    private static final String WORKER_PREFIX = "/worker-";

    private CuratorFramework client;
    private String workerId;
    private String workerPath;
    private String assignPath;

    private ExecutorService executorService;
    private String workerName;
    private PathChildrenCache assignmentCache;

    public Worker() {
        this.executorService = Executors.newSingleThreadExecutor();
    }

    PathChildrenCacheListener assignWorkersCacheListener = (client1, event) -> {
        try {
            switch (event.getType()) {
                case CHILD_ADDED:
                    startJob(event.getData());
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            LOG.error("Exception occurs while job worker updated:", e);
        }
    };

    protected String generateWorkerId() {
        return ZKConstants.getHostName() + "_" + System.currentTimeMillis();
    }

    public void start() throws Exception {
        try {
            client = CuratorClientFactory.create();
            client.getConnectionStateListenable().addListener((client1, newState) -> {
                LOG.info("Worker: " + workerId + " connection status:" + newState.name());
                if (newState.equals(ConnectionState.RECONNECTED)) {
                    reconnect(client1);
                }
            });
            client.start();
            LOG.info("zookeeper info:Has boot zookeeper client: worker " + workerId);
            workerId = generateWorkerId();
            workerName = WORKER_PREFIX + workerId;
            workerPath = ZKConstants.WORKERS_PATH + workerName;
            assignPath = ZKConstants.ASSIGN_PATH + workerName;
            createWorker();
            LOG.info("zookeeper info: zookeeper worker has been created, workerId: " + workerId);
        } catch (Exception e) {
            LOG.error("Error occurs when init Worker!");
            throw e;
        }
    }

    private void reconnect(final CuratorFramework client) {
        try {
            if (client.checkExists().forPath(ZKConstants.WORKERS_PATH + WORKER_PREFIX + workerId) == null) {
                workerId = generateWorkerId();
                workerName = WORKER_PREFIX + workerId;
                workerPath = ZKConstants.WORKERS_PATH + workerName;
                assignPath = ZKConstants.ASSIGN_PATH + workerName;
                if (client.checkExists().forPath(ZKConstants.WORKERS_PATH + WORKER_PREFIX + workerId) == null) {
                    createWorkerNode();
                }
            }
        } catch (Exception e) {
            LOG.error("JobWorker reconnect error:", e);
        }
    }

    private static final AtomicInteger synchronizeToken = new AtomicInteger(1);

    private static void bootstrap(CuratorFramework client) throws Exception {
        synchronized (synchronizeToken) {
            if (client.checkExists().forPath(ZKConstants.ZK_BASE_PATH) == null) {
                client.create().forPath(ZKConstants.ZK_BASE_PATH, new byte[0]);
            }
            if (client.checkExists().forPath(ZKConstants.WORKERS_PATH) == null) {
                client.create().forPath(ZKConstants.WORKERS_PATH, new byte[0]);
            }
            if (client.checkExists().forPath(ZKConstants.ASSIGN_PATH) == null) {
                client.create().forPath(ZKConstants.ASSIGN_PATH, new byte[0]);
            }
            if (client.checkExists().forPath(ZKConstants.TASKS_PATH) == null) {
                client.create().forPath(ZKConstants.TASKS_PATH, new byte[0]);
            }
        }
    }

    private void createWorker() throws Exception {
        bootstrap(client);
        createWorkerNode();
    }

    private void createWorkerNode() throws Exception {

        client.create().withMode(CreateMode.EPHEMERAL).inBackground().forPath(workerPath, new byte[0]);

        client.create().withMode(CreateMode.PERSISTENT).inBackground().forPath(assignPath, new byte[0]);

        if (assignmentCache != null){
            try {
                assignmentCache.close();
            } catch (Exception e){
                LOG.error("Worker: PathChildrenCache close error:", e);
            }
        }
        assignmentCache = new PathChildrenCache(this.client, assignPath, true);

        assignmentCache.getListenable().addListener(assignWorkersCacheListener);
        assignmentCache.start();
    }


    private static AtomicInteger executionCount = new AtomicInteger(0);
    private static AtomicInteger blockedCount = new AtomicInteger(0);

    public static AtomicInteger getExecutionCount() {
        return executionCount;
    }

    public static AtomicInteger getBlockedCount() {
        return blockedCount;
    }

    private void startJob(ChildData childData) {
        String taskName = childData.getPath().substring(childData.getPath().lastIndexOf("/") + 1);

        ZKTaskData taskData = (ZKTaskData) SerializationUtils.deserialize(childData.getData());
        LOG.info(workerId + " Running Task[" + taskName + "]: " + taskData);
        runTask(taskData);
    }

    private void runTask(ZKTaskData taskData) {

        executorService.submit(() -> {
            executionCount.getAndIncrement();
            LOG.info("task: {}, executionCount: {}", taskData.getTaskName(), executionCount.get());

            executeTask(taskData);
        });
    }

    private void executeTask(ZKTaskData taskData) {
        List<PessimisticPermit> pessimisticPermits = new ArrayList<>();
        CuratorFramework curator = CuratorClientFactory.create();
        try {
            curator.start();

            if (checkCancel(taskData.getTaskName(), taskData.getBackgroundTask(), curator) || checkPause(taskData, curator)) {
                return;
            }

            final String statusNodePath = ZKConstants.STATUS_PATH + "/" + taskData.getTaskName();
            TaskStatus taskStatus = new TaskStatus(TaskExecutionStatus.STARTED, workerName);
            if (curator.checkExists().forPath(statusNodePath) == null) {
                LOG.info("create status: " + statusNodePath);
                curator.create().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            } else {
                byte[] bytes = curator.getData().forPath(statusNodePath);
                TaskStatus existedTaskStatus = (TaskStatus) SerializationUtils.deserialize(bytes);
                if (existedTaskStatus.getStatus().isDone()) {
                    LOG.warn("{} already been executed!", taskData.getTaskName());
                    return;
                } else if (TaskExecutionStatus.STARTED == existedTaskStatus.getStatus()) {
                    LOG.warn("{} is being executed!", taskData.getTaskName());
                    return;
                }
                LOG.info("set status to started: " + statusNodePath);
                curator.setData().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            }
            BackgroundTask backgroundTask = taskData.getBackgroundTask();
            List<PessimisticPermitType> permits = new ArrayList<>(backgroundTask.getPessimisticPermitsRequired());
            Collections.sort(permits);

            boolean allPermitsAcquired = true;
            Set<String> blockedBy = new HashSet<>();
            for (PessimisticPermitType permit : permits) {
                PessimisticPermit pessimisticPermit = new PessimisticLock(permit, taskData.getTaskName()).acquireLock();
                pessimisticPermits.add(pessimisticPermit);
                if (!pessimisticPermit.isAcquired()) {
                    allPermitsAcquired = false;
                    blockedBy.add(pessimisticPermit.getOwner());
                    break;
                }
            }

            if (allPermitsAcquired) {
                executeBackgroundTask(taskStatus, backgroundTask);
            } else {
                blockedCount.getAndIncrement();
                taskStatus.setStatus(TaskExecutionStatus.BLOCKED);

                taskData.setBlockedBy(blockedBy);
                LOG.info("Job blocked! " + taskData);
                curator.create().withMode(CreateMode.PERSISTENT)
                        .forPath(ZKConstants.BLOCKED_TASKS_PATH + "/" + taskData.getTaskName(), SerializationUtils.serialize(taskData));

            }

            curator.setData().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            LOG.info("set status to " + taskStatus.getStatus() + ": "+ statusNodePath);

        } catch (Exception e) {
            LOG.error("error when " + workerName + " executing task: " +  taskData.getTaskName());
            LOG.error(e.getMessage(), e);
        } finally {
            try {
                curator.delete().guaranteed().inBackground().forPath(assignPath + "/" + taskData.getTaskName());
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
            LOG.info("delete assign: " + assignPath + "/" + taskData.getTaskName());

            Lists.reverse(pessimisticPermits).forEach(PessimisticPermit::release);
            curator.close();
        }
    }

    private boolean checkPause(final ZKTaskData taskData, final CuratorFramework curator) throws Exception {
        boolean paused = false;
        String taskName = taskData.getTaskName();
        String commandPath = ZKConstants.COMMAND_PAUSE_PATH + "/" + taskName;
        if (curator.checkExists().forPath(commandPath) != null) {
            taskData.getBackgroundTask().pause();
            LOG.info("{} paused! ", taskName);
            curator.create().withMode(CreateMode.PERSISTENT)
                    .forPath(ZKConstants.PAUSED_TASKS_PATH + "/" + taskData.getTaskName(), SerializationUtils.serialize(taskData));
            TaskStatus taskStatus = new TaskStatus(TaskExecutionStatus.PAUSED, workerName);
            String statusNodePath = ZKConstants.STATUS_PATH + "/" + taskName;
            if (curator.checkExists().forPath(statusNodePath) == null) {
                curator.create().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            } else {
                curator.setData().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            }
            curator.delete().forPath(commandPath);
            paused = true;
        }
        return paused;
    }

    private boolean checkCancel(final String taskName, BackgroundTask backgroundTask, final CuratorFramework curator) throws Exception {
        boolean canceled = false;
        String commandPath = ZKConstants.COMMAND_CANCEL_PATH + "/" + taskName;
        if (curator.checkExists().forPath(commandPath) != null) {
            backgroundTask.cancel();
            LOG.info("{} canceled! ", taskName);
            TaskStatus taskStatus = new TaskStatus(TaskExecutionStatus.CANCELED, workerName);
            String statusNodePath = ZKConstants.STATUS_PATH + "/" + taskName;
            if (curator.checkExists().forPath(statusNodePath) == null) {
                curator.create().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            } else {
                curator.setData().forPath(statusNodePath, SerializationUtils.serialize(taskStatus));
            }
            curator.delete().forPath(commandPath);
            canceled = true;
        }
        return canceled;
    }

    private void executeBackgroundTask(TaskStatus taskStatus, BackgroundTask backgroundTask) {
        try {
            backgroundTask.execute();
            taskStatus.setStatus(TaskExecutionStatus.COMPLETED);
        } catch (Exception e) {
            LOG.error("error when " + workerName + " executing background task: " +  backgroundTask.getTaskName());
            LOG.error(e.getMessage(), e);
            taskStatus.setStatus(TaskExecutionStatus.FAILED);
        }
    }

    public boolean isConnected() {
        return client.getZookeeperClient().isConnected();
    }

    public Map<String, List<ZKTaskData>> getAssignedTask() throws Exception {
        Map<String, List<ZKTaskData>> map = new HashMap<>();
        List<String> workers = client.getChildren().forPath(ZKConstants.ASSIGN_PATH);
        for (String worker : workers) {
            List<ZKTaskData> jobDataList = new ArrayList<>();
            map.put(worker, jobDataList);
            for (String task : client.getChildren().forPath(ZKConstants.ASSIGN_PATH + "/" + worker)) {
                byte[] data = client.getData().forPath(ZKConstants.ASSIGN_PATH + "/" + worker + "/" + task);
                jobDataList.add((ZKTaskData) SerializationUtils.deserialize(data));
            }
        }
        return map;
    }

    @PreDestroy
    public void close() throws IOException {
        LOG.info("Zookeeper client: worker close connection.");
        if (assignmentCache != null){
            try {
                assignmentCache.close();
            } catch (Exception e){
                LOG.error("Worker: PathChildrenCache close error:", e);
            }
        }
        client.close();
        executorService.shutdownNow();
    }

}