package com.lombardrisk.coordination.permit.imps;

import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import org.apache.curator.utils.PathUtils;

public class PessimisticPermitTypeImpl implements PessimisticPermitType {

    private static final String LOCK_PATH_PREFIX = "/com.lombardrisk.colline/locks";

    private String name = "";
    private String grainIdentifier = ""; // only trade feed currently uses this, with sourceSystem
    private Mode mode = Mode.WRITE;
    private int priority = 0;

    public PessimisticPermitTypeImpl(String name, String grainIdentifier, Mode mode, int priority) {
        this.name = name;
        this.grainIdentifier = grainIdentifier;
        this.mode = mode;
        this.priority = priority;
        generateLockPath();
    }

    @Override
    public int compareTo(PessimisticPermitType that) {
        if (that instanceof PessimisticPermitTypeImpl) {
            PessimisticPermitTypeImpl o = (PessimisticPermitTypeImpl) that;
            return ComparisonChain.start()
                    .compare(this.priority, o.priority)
                    .compare(this.lockPath, o.lockPath, Ordering.natural().nullsLast())
                    .compare(this.mode, o.mode)
                    .result();
        } else {
            return ComparisonChain.start()
                    .compare(this.lockPath, that.getLockPath(), Ordering.natural().nullsLast())
                    .result();
        }
    }

    private String lockPath;

    private void generateLockPath() {
        lockPath = LOCK_PATH_PREFIX + "/" + name;
        if (grainIdentifier != null && !grainIdentifier.isEmpty()) {
            lockPath += "/" + grainIdentifier;
        }
        lockPath = PathUtils.validatePath(lockPath);
    }

    @Override
    public String getLockPath() {
        return lockPath;
    }

    @Override
    public Mode getMode() {
        return mode;
    }
}
