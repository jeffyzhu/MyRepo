package com.lombardrisk.coordination;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;

public final class CuratorClientFactory {

    private CuratorClientFactory() {
    }

    public static final String ZOOKEEPER_CONNECT_STRING = "colline.zookeeper.connection.string";
    private static final String CONNECT_STRING = System.getProperty(ZOOKEEPER_CONNECT_STRING, "127.0.0.1:2181");
    private static final int CONNECTION_TIMEOUT_TWO_SECONDS = 2000;
    private static final int SESSION_TIMEOUT_TWO_SECONDS = 2000;
    private static final int BASE_SLEEP_TIME_ONE_SECOND = 1000;
    private static final int MAX_RETRIES_THREE = 3;
    static {
        System.setProperty("zookeeper.sasl.client", "false");
    }

    /**
     * Create a Curator Client
     *
     * @return Curator Client
     */
    public static CuratorFramework create() {
        // these are reasonable arguments for the ExponentialBackoffRetry. The first
        // retry will wait 1 second - the second will wait up to 2 seconds - the
        // third will wait up to 4 seconds.
        ExponentialBackoffRetry retryPolicy = new ExponentialBackoffRetry(BASE_SLEEP_TIME_ONE_SECOND, MAX_RETRIES_THREE);
        return CuratorFrameworkFactory.newClient(CONNECT_STRING, SESSION_TIMEOUT_TWO_SECONDS, CONNECTION_TIMEOUT_TWO_SECONDS, retryPolicy);
    }
}
