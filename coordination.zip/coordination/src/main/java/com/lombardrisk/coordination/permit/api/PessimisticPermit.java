package com.lombardrisk.coordination.permit.api;

public interface PessimisticPermit {

    void release();

    boolean isAcquired();

    String getOwner();
}
