package com.lombardrisk.coordination.permit.api;

import java.io.Serializable;

public interface PessimisticPermitType extends Comparable<PessimisticPermitType>, Serializable {

    String getLockPath();

    Mode getMode();

    enum Mode {
        READ,
        WRITE
    }
}
