package com.lombardrisk.coordination.task.imps;

import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.task.api.TaskResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CountDownLatch;

class TaskResponseImpl implements TaskResponse {
    private static final Logger LOG = LoggerFactory.getLogger(TaskResponseImpl.class);
    private String taskName;
    private String taskPath;
    private String taskStatus;
    private boolean end = false;
    private CountDownLatch latch = new CountDownLatch(1);
    private CountDownLatch submitLatch = new CountDownLatch(1);

    @Override
    public String getTaskName() {
        return taskName;
    }

    void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    void setTaskPath(String name) {
        this.taskPath = name;
    }

    @Override
    public String getTaskPath() {
        return taskPath;
    }

    @Override
    public String getTaskStatus() {
        return taskStatus;
    }

    synchronized void setStatus(ZKConstants.TaskExecutionStatus status) {
        if (status.isEnd()) {
            end = true;
            latch.countDown();
        }
        this.taskStatus = status.toString();
    }

    void submitted() {
        submitLatch.countDown();
    }

    @Override
    public void waitUntilSubmitted() {
        try {
            LOG.info("Waiting submit: " + taskPath);
            submitLatch.await();
            LOG.info("Submitted: " + taskPath);
        } catch (InterruptedException e) {
            LOG.warn("InterruptedException while waiting for task to get submitted");
        }
    }

    @Override
    public void waitUntilEnd() {
        try {
            LOG.info("Waiting: " + taskPath);
            latch.await();
            LOG.info("End: " + taskPath);
        } catch (InterruptedException e) {
            LOG.warn("InterruptedException while waiting for task to get end");
        }
    }

    @Override
    public synchronized boolean isEnd() {
        return end;
    }
}
