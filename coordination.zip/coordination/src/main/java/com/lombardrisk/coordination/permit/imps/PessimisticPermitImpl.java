package com.lombardrisk.coordination.permit.imps;

import com.google.common.base.MoreObjects;
import com.lombardrisk.coordination.permit.api.PessimisticPermit;

class PessimisticPermitImpl implements PessimisticPermit {

    private final String lockPath;
    private boolean acquired = false;
    private String owner = "";
    private final PessimisticLock lock;

    PessimisticPermitImpl(String lockPath, PessimisticLock lock) {
        this.lockPath = lockPath;
        this.lock = lock;
    }

    /**
     * Perform one release of the lock.
     */
    @Override
    public void release() {
        if (lock != null) {
            lock.release();
        }
    }

    String getLockPath() {
        return lockPath;
    }

    @Override
    public boolean isAcquired() {
        return acquired;
    }

    void setAcquired(final boolean acquired) {
        this.acquired = acquired;
    }

    @Override
    public String getOwner() {
        return owner;
    }

    void setOwner(final String owner) {
        this.owner = owner;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("lockPath", lockPath)
                .add("acquired", acquired)
                .add("owner", owner)
                .add("lock", lock)
                .toString();
    }
}
