package com.lombardrisk.coordination.task.api;

import com.lombardrisk.coordination.exception.CoordinationException;

import java.io.Closeable;
import java.util.List;

public interface TaskClient extends Closeable {
    /**
     * Submit the task to server.
     * Will not wait the task to be submitted or completed.
     *
     * @param task defined task
     * @return TaskResponse
     * @throws CoordinationException exception when submitting the task
     *
     * @see com.lombardrisk.coordination.task.api.TaskResponse
     */
    TaskResponse submitTask(BackgroundTask task) throws CoordinationException;

    TaskResponse checkTask(String taskName) throws CoordinationException;

    List<String> cancelAllTasks() throws CoordinationException;

    List<String> pauseAllTasks() throws CoordinationException;

    void cancelTask(String taskName) throws CoordinationException;

    void pauseTask(String taskName) throws CoordinationException;

    List<String> resumeAllTasks();

    void resumeTask(String taskName) throws CoordinationException;
}
