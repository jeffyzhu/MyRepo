package com.lombardrisk.coordination.task.framework;

import com.google.common.base.MoreObjects;
import com.lombardrisk.coordination.ZKConstants.TaskExecutionStatus;

import java.io.Serializable;

public class TaskStatus implements Serializable {
    private static final long serialVersionUID = 5161432188148680344L;
    private TaskExecutionStatus status;
    private String updatedBy;

    public TaskStatus(final TaskExecutionStatus status, final String updatedBy) {
        this.status = status;
        this.updatedBy = updatedBy;
    }

    public TaskExecutionStatus getStatus() {
        return status;
    }

    void setStatus(final TaskExecutionStatus status) {
        this.status = status;
    }

    String getUpdatedBy() {
        return updatedBy;
    }

    void setUpdatedBy(final String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("status", status)
                .add("updatedBy", updatedBy)
                .toString();
    }
}
