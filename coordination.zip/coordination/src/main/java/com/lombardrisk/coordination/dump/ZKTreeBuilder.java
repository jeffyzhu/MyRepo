package com.lombardrisk.coordination.dump;

import com.lombardrisk.common.structures.TreeNode;
import com.lombardrisk.common.util.LogUtil;
import com.lombardrisk.coordination.CuratorClientFactory;
import org.apache.curator.framework.CuratorFramework;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;

public class ZKTreeBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(ZKTreeBuilder.class);

    private final String startZNode;
    private TreeNode<ZNode> zkTree = null;

    private CuratorFramework client;


    public ZKTreeBuilder(String zNode) {
        this.startZNode = zNode;
    }

    public TreeNode<ZNode> getZKTree() {
        zkTree = null;
        this.client = CuratorClientFactory.create();
        client.start();
        try {
            build();
        } finally {
            if (this.client != null) {
                this.client.close();
            }
        }
        return zkTree;
    }

    private void build() {
        buildChild(startZNode, "", null);
    }

    private void buildChild(String znodeParent, String zNodeName, TreeNode<ZNode> treeNode) {
        String znodePath = (znodeParent.equals("/") ? "" : znodeParent) + ("".equals(zNodeName) ? "" : ("/" + zNodeName));
        if ("".equals(znodePath)) {
            znodePath ="/";
        }

        List<String> children;
        try {
            children = client.getChildren().forPath(znodePath);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            children = Collections.emptyList();
        }
        LogUtil.safeDebug(LOG, "get children for path: " + znodePath);

        Stat stat = new Stat();
        byte[] data = new byte[0];
        try {
            data = client.getData().storingStatIn(stat).forPath(znodePath);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
        LogUtil.safeDebug(LOG, "get data for path: " + znodePath);
        ZNode z = new ZNode(zNodeName, znodePath, data, stat);
        TreeNode<ZNode> tNode;
        if (treeNode != null) {
            tNode = treeNode.addChild(z);
        } else {
            zkTree = new TreeNode<>(z);
            tNode = zkTree;
        }
        for (String c : children) {
            buildChild(znodePath, c, tNode);
        }
    }

}
