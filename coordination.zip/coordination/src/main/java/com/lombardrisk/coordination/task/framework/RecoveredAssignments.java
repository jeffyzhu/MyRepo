/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lombardrisk.coordination.task.framework;

import com.google.common.base.MoreObjects;
import com.lombardrisk.coordination.ZKConstants;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.zookeeper.AsyncCallback.ChildrenCallback;
import org.apache.zookeeper.AsyncCallback.StringCallback;
import org.apache.zookeeper.AsyncCallback.VoidCallback;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * This class implements a task to recover assignments after
 * a primary master crash. The main idea is to determine the
 * tasks that have already been assigned and assign the ones
 * that haven't
 *
 */
public class RecoveredAssignments {
    private static final Logger LOG = LoggerFactory.getLogger(RecoveredAssignments.class);
    private static final String GET_CHILDREN_FAILED = "getChildren failed";
    static final String GETTING_STATUSES_FOR_RECOVERY = "Getting statuses for recovery";

    /*
     * Various lists wew need to keep track of.
     */
    List<String> tasks;
    List<String> assignments;
    List<String> activeWorkers;
    List<String> assignedWorkers;

    RecoveryCallback cb;

    ZooKeeper zk;

    /**
     * Callback interface. Called once
     * recovery completes or fails.
     *
     */
    public interface RecoveryCallback {
        int OK = 0;
        int FAILED = -1;

        void recoveryComplete(int rc, List<String> tasks);
    }

    /**
     * Recover unassigned tasks.
     *
     */
    public RecoveredAssignments(ZooKeeper zk){
        this.zk = zk;
        this.assignments = new ArrayList<>();
    }

    /**
     * Starts recovery.
     *
     */
    public void recover(RecoveryCallback recoveryCallback){
        // Read task list with getChildren
        cb = recoveryCallback;
        getTasks();
    }

    private void getTasks(){
        zk.getChildren(ZKConstants.TASKS_PATH, false, tasksCallback, null);
    }

    ChildrenCallback tasksCallback = new ChildrenCallback(){
        public void processResult(int rc, String path, Object ctx, List<String> children){
            switch (Code.get(rc)) {
            case CONNECTIONLOSS:
                getTasks();

                break;
            case OK:
                LOG.info("Getting tasks for recovery: " + children);
                tasks = children;
                getAssignedWorkers();

                break;
            default:
                LOG.error(GET_CHILDREN_FAILED,  KeeperException.create(Code.get(rc), path));
                cb.recoveryComplete(RecoveryCallback.FAILED, null);
            }
        }
    };

    private void getAssignedWorkers(){
        zk.getChildren(ZKConstants.ASSIGN_PATH, false, assignedWorkersCallback, null);
    }

    ChildrenCallback assignedWorkersCallback = new ChildrenCallback(){
        public void processResult(int rc, String path, Object ctx, List<String> children){
            switch (Code.get(rc)) {
            case CONNECTIONLOSS:
                getAssignedWorkers();

                break;
            case OK:
                assignedWorkers = children;
                getWorkers(children);

                break;
            default:
                LOG.error(GET_CHILDREN_FAILED,  KeeperException.create(Code.get(rc), path));
                cb.recoveryComplete(RecoveryCallback.FAILED, null);
            }
        }
    };

    private void getWorkers(Object ctx){
        zk.getChildren(ZKConstants.WORKERS_PATH, false, workersCallback, ctx);
    }


    ChildrenCallback workersCallback = new WorkersCallback();

    private void getWorkerAssignments(String s) {
        zk.getChildren(s, false, workerAssignmentsCallback, null);
    }

    ChildrenCallback workerAssignmentsCallback = new WorkerAssignmentsCallback();

    void getBlockedTasks() {
        zk.getChildren(ZKConstants.BLOCKED_TASKS_PATH, false, blockedTasksCallback, null);
    }

    ChildrenCallback blockedTasksCallback = new BlockedTasksCallback();

    /**
     * Get data of task being reassigned.
     *
     */
    void getDataReassign(String path, String task) {
        LOG.info("getDataReassign path:{}, task:{}", path, task);
        byte[] data = new byte[0];
        try {
            data = zk.getData(path + "/" + task, false, null);
        } catch (KeeperException | InterruptedException e) {
            LOG.error(e.getMessage(), e);
        }
        recreateTask(new RecreateTaskCtx(path, task, data));
    }

    /**
     * Context for recreate operation.
     *
     */
    static class RecreateTaskCtx {
        String path;
        String task;
        byte[] data;

        RecreateTaskCtx(String path, String task, byte[] data) {
            this.path = path;
            this.task = task;
            this.data = data;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(this)
                    .add("path", path)
                    .add("task", task)
                    .add("data", data)
                    .toString();
        }
    }

    /**
     * Recreate task znode in /tasks
     *
     * @param ctx Recreate text context
     */
    void recreateTask(RecreateTaskCtx ctx) {
        LOG.info("recreateTask: {}", ctx);
        zk.create(ZKConstants.TASKS_PATH + "/" + ctx.task,
                ctx.data,
                Ids.OPEN_ACL_UNSAFE,
                CreateMode.PERSISTENT,
                recreateTaskCallback,
                ctx);
    }

    /**
     * Recreate znode callback
     */
    StringCallback recreateTaskCallback = new StringCallback() {
        public void processResult(int rc, String path, Object ctx, String name) {
            RecreateTaskCtx taskCtx = (RecreateTaskCtx) ctx;
            switch(Code.get(rc)) {
            case CONNECTIONLOSS:
                recreateTask(taskCtx);

                break;
            case OK:
                deleteAssignment(taskCtx.path + "/" + taskCtx.task);

                break;
            case NODEEXISTS:
                LOG.warn("Node shouldn't exist: " + path);

                break;
            default:
                LOG.error("Something wwnt wrong when recreating task",
                        KeeperException.create(Code.get(rc)));
            }
        }
    };

    /**
     * Delete assignment of absent worker
     *
     * @param path Path of znode to be deleted
     */
    void deleteAssignment(String path){
        zk.delete(path, -1, taskDeletionCallback, null);
    }

    VoidCallback taskDeletionCallback = new VoidCallback(){
        public void processResult(int rc, String path, Object rtx) {
            switch (Code.get(rc)) {
                case CONNECTIONLOSS:
                    deleteAssignment(path);
                    break;
                case OK:
                    LOG.info("Correctly deleted: " + path);
                    break;
                case NONODE:
                    LOG.warn("Failed to delete the path " +
                            KeeperException.create(Code.get(rc), path));
                    break;
                default:
                    LOG.error("Failed to delete the path " +
                            KeeperException.create(Code.get(rc), path));
            }
        }
    };

    private void processAssignments(){
        LOG.info("Size of tasks: " + tasks.size());
        // Process list of pending assignments
        for(String s: assignments){
            LOG.info("Assignment: " + s);
            deleteAssignment(ZKConstants.TASKS_PATH + "/" + s);
            tasks.remove(s);
        }

        LOG.info("Size of tasks after assignment filtering: " + tasks.size());


        // Invoke callback
        cb.recoveryComplete(RecoveryCallback.OK, tasks);
    }

    private class BlockedTasksCallback implements ChildrenCallback {
        public void processResult(int rc, String path, Object ctx, List<String> children){
            switch (Code.get(rc)) {
                case CONNECTIONLOSS:
                    getBlockedTasks();
                    break;
                case OK:
                    LOG.info("pending tasks: " + children);
                    for (String task : children) {
                        LOG.info("move pending task to tasks: " + task);
                        tasks.add(task);
                        getDataReassign(path, task);
                    }
                    LOG.info(GETTING_STATUSES_FOR_RECOVERY);

                    processAssignments();

                    break;
                default:
                    LOG.error(GET_CHILDREN_FAILED,  KeeperException.create(Code.get(rc), path));
                    cb.recoveryComplete(RecoveryCallback.FAILED, null);
            }
        }
    }

    private class WorkersCallback implements ChildrenCallback {
        public void processResult(int rc, String path, Object ctx, List<String> children){
            switch (Code.get(rc)) {
            case CONNECTIONLOSS:
                getWorkers(ctx);
                break;
            case OK:
                LOG.info("Getting worker assignments for recovery: " + children.size());
                /*
                 * No worker available yet, so the master is probably let's just return an empty list.
                 */
                if (children.size() == 0) {
                    LOG.warn("Empty list of workers, possibly just starting");
                    cb.recoveryComplete(RecoveryCallback.OK, new ArrayList<>());
                    break;
                }

                /*
                 * Need to know which of the assigned workers are active.
                 */

                activeWorkers = children;
                for (String s : assignedWorkers) {
                    getWorkerAssignments(ZKConstants.ASSIGN_PATH + "/" + s);
                }

                break;
            default:
                LOG.error(GET_CHILDREN_FAILED,  KeeperException.create(Code.get(rc), path));
                cb.recoveryComplete(RecoveryCallback.FAILED, null);
            }
        }
    }

    private TaskStatus getTaskStatus(String taskPath) throws KeeperException, InterruptedException {
        TaskStatus taskStatus = null;
        try {
            byte[] statusBytes = zk.getData(taskPath, false, null);
            taskStatus = (TaskStatus) SerializationUtils.deserialize(statusBytes);
        } catch (KeeperException.NoNodeException e) {
            LOG.debug(e.getMessage(), e);
            LOG.warn(e.getMessage());
        }
        return taskStatus;
    }

    private class WorkerAssignmentsCallback implements ChildrenCallback {
        public void processResult(int rc,
                String path,
                Object ctx,
                List<String> children) {
            switch (Code.get(rc)) {
            case CONNECTIONLOSS:
                getWorkerAssignments(path);
                break;
            case OK:
                LOG.info("{} has children {}", path, children);
                String worker = path.replace(ZKConstants.ASSIGN_PATH + "/", "");

                /*
                 * If the worker is in the list of active
                 * workers, then we add the tasks to the
                 * assignments list. Otherwise, we need to
                 * re-assign those tasks, so we add them to
                 * the list of tasks.
                 */
                if (activeWorkers.contains(worker)) {
                    assignments.addAll(children);
                } else {
                    for (String task : children) {

                        checkTask4AbsentWorker(path, task);

                        /*
                         * If the task is still in the list
                         * we delete the assignment.
                         */
                        deleteAssignment(path + "/" + task);
                    }
                    /*
                     * Delete the assignment parent.
                     */
                    deleteAssignment(path);

                }

                assignedWorkers.remove(worker);

                /*
                 * Once we have checked all assignments,
                 * it is time to check the status of tasks
                 */
                if (assignedWorkers.size() == 0) {
                    LOG.info(GETTING_STATUSES_FOR_RECOVERY);
                    getBlockedTasks();
                }

                break;
            case NONODE:
                LOG.info( "No such znode exists: " + path );
                worker = path.replace(ZKConstants.ASSIGN_PATH + "/", "");
                assignedWorkers.remove(worker);
                if (assignedWorkers.size() == 0) {
                    LOG.info(GETTING_STATUSES_FOR_RECOVERY);
                    getBlockedTasks();
                }
                break;
            default:
                LOG.error(GET_CHILDREN_FAILED,  KeeperException.create(Code.get(rc), path));
                cb.recoveryComplete(RecoveryCallback.FAILED, null);
            }
        }

        private void checkTask4AbsentWorker(final String path, final String task) {
            String statusPath = ZKConstants.STATUS_PATH + "/" + task;
            TaskStatus taskStatus = null;
            boolean errorWhenGetStatus = false;
            try {
                taskStatus = getTaskStatus(statusPath);
            } catch (KeeperException | InterruptedException e) {
                LOG.error(e.getMessage(), e);
                errorWhenGetStatus = true;
            }
            if (!errorWhenGetStatus) {
                if (taskStatus == null) {
                    if (!tasks.contains(task)) {
                        LOG.info("add to tasks: " + task);
                        tasks.add(task);
                        getDataReassign(path, task);
                    }
                } else if (taskStatus.getStatus() == ZKConstants.TaskExecutionStatus.STARTED) {
                    taskStatus.setStatus(ZKConstants.TaskExecutionStatus.INTERRUPTED);
                    try {
                        zk.setData(statusPath, SerializationUtils.serialize(taskStatus), -1);
                        LOG.info("set {} to interrupted! ", task);
                    } catch (KeeperException | InterruptedException e) {
                        LOG.error(e.getMessage(), e);
                    }
                }
            }
        }
    }
}
