package com.lombardrisk.coordination.permit;

import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.permit.api.PessimisticPermit;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import com.lombardrisk.coordination.permit.imps.PessimisticLock;
import com.lombardrisk.coordination.permit.imps.PessimisticPermitTypeImpl;

import java.util.concurrent.TimeUnit;

import static com.lombardrisk.coordination.permit.api.PessimisticPermitType.Mode;

public final class PermitsCenter {

    private PermitsCenter() {
    }

    public static PessimisticPermit applyPermit(PessimisticPermitType type, String applicant) {
        return new PessimisticLock(type, applicant).acquireLock();
    }

    public static PessimisticPermit applyPermit(PessimisticPermitType type) {
        return new PessimisticLock(type, ZKConstants.getHostName() + "--" + Thread.currentThread()).acquireLock();
    }

    public static PessimisticPermit applyPermit(PessimisticPermitType type, long time, TimeUnit unit) {
        return new PessimisticLock(type, ZKConstants.getHostName() + "--" + Thread.currentThread()).acquireLock(time, unit);
    }

    /**
     * define a permit type
     *
     * @param name permit type name
     * @param grainIdentifier grain identifier of the permit, such as agreementId, eventId
     * @param mode read or write
     * @param priority when acquiring several permits at same time, permit with lower priority will be applied first
     * @return defined permit type
     */
    public static PessimisticPermitType definePermitType(String name, String grainIdentifier, Mode mode, int priority) {
        return new PessimisticPermitTypeImpl(name, grainIdentifier, mode, priority);
    }

    public static PessimisticPermitType definePermitType(String name, Mode mode, int priority) {
        return new PessimisticPermitTypeImpl(name, "", mode, priority);
    }

    public static PessimisticPermitType definePermitType(String name, Mode mode) {
        return new PessimisticPermitTypeImpl(name, "", mode, 0);
    }

    public static PessimisticPermitType defineWritePermitType(String name) {
        return new PessimisticPermitTypeImpl(name, "", Mode.WRITE, 0);
    }

    public static PessimisticPermitType defineWritePermitType(String name, String grainIdentifier) {
        return new PessimisticPermitTypeImpl(name, grainIdentifier, Mode.WRITE, 0);
    }
}