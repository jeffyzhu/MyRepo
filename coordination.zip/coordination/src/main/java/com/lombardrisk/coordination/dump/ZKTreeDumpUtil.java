package com.lombardrisk.coordination.dump;

import com.google.common.base.Charsets;
import com.google.common.graph.Traverser;
import com.lombardrisk.common.structures.TreeNode;
import com.lombardrisk.coordination.ZKConstants;
import org.apache.commons.lang3.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public final class ZKTreeDumpUtil {
    private ZKTreeDumpUtil() {
    }

    private static final Logger LOG = LoggerFactory.getLogger(ZKTreeDumpUtil.class);

    private static final Traverser<TreeNode<ZNode>> traverser = Traverser.forTree(TreeNode::getChildren);

    public static byte[] dumpToXML(String startZNode) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            TreeNode<ZNode> zkTree = new ZKTreeBuilder(startZNode).getZKTree();

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();
            Element root = doc.createElement("root");
            root.setAttribute("path", startZNode);
            doc.appendChild(root);

            fillXml(doc, root, zkTree);

            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.METHOD, "xml");
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            t.transform(new DOMSource(doc), new StreamResult(out));
            return out.toByteArray();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
        return new byte[0];
    }

    private static String getZNodeValue(ZNode zNode) {
        String path = zNode.path;
        if (path != null && (path.contains(ZKConstants.STATUS_PATH) || path.contains(ZKConstants.ASSIGN_PATH + "/worker-") || isTasksPath(path))) {
            return SerializationUtils.deserialize(zNode.data).toString();
        } else {
            return new String(zNode.data, Charsets.UTF_8);
        }
    }

    private static boolean isTasksPath(final String path) {
        return path.contains(ZKConstants.TASKS_PATH) || path.contains(ZKConstants.BLOCKED_TASKS_PATH) ||
                path.contains(ZKConstants.PAUSED_TASKS_PATH);
    }

    private static void fillXml(Document doc, Node root, TreeNode<ZNode> zkTree) {
        for (TreeNode<ZNode> znode : zkTree.getChildren()) {
            Element node = doc.createElement("zkNode");
            node.setAttribute("name", znode.getData().name);
            if (znode.getData().data != null && znode.getData().data.length > 0) {
                String str = getZNodeValue(znode.getData());
                if (!str.equals("null")) {
                    node.setAttribute("value", str);
                }
            }
            if (znode.getData().stat.getEphemeralOwner() != 0) {
                node.setAttribute("ephemeral", "true");
            }

            root.appendChild(node);
            fillXml(doc, node, znode);
        }
    }

    public static byte[] dumpToTxt(String startZNode) {
        ByteArrayOutputStream out = null;
        Writer writer = null;
        try {
            out = new ByteArrayOutputStream();
            writer = new OutputStreamWriter(out, Charsets.UTF_8);
            TreeNode<ZNode> zkTree = new ZKTreeBuilder(startZNode).getZKTree();

            for (TreeNode<ZNode> znode : traverser.depthFirstPreOrder(zkTree)) {
                writer.write("path=" + znode.getData().path);
                if (znode.getData().data != null && znode.getData().data.length > 0) {
                    String str = getZNodeValue(znode.getData());
                    if (!str.equals("null")) {
                        writer.write("\t");
                        writer.write("val=" + str);
                    }
                }

                if (znode.getData().stat.getEphemeralOwner() != 0) {
                    writer.write("\t");
                    writer.write("type='ephemeral'");
                }
                writer.write(System.lineSeparator());
            }
            writer.flush();
            return out.toByteArray();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return new byte[0];
    }
}
