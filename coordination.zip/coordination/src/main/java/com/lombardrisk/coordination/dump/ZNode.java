
package com.lombardrisk.coordination.dump;

import org.apache.zookeeper.data.Stat;

public class ZNode {
    String name;
    String path;
    byte[] data = null;
    Stat stat;

    public ZNode(String name, String path, byte[] data, Stat stat) {
        this.name = name;
        this.path = path;
        if (data != null) {
            this.data = data.clone();
        }
        this.stat = stat;
    }

}
