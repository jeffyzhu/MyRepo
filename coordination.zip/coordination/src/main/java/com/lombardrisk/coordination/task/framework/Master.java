package com.lombardrisk.coordination.task.framework;

import com.lombardrisk.coordination.CuratorClientFactory;
import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.ZKConstants.TaskExecutionStatus;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.api.CuratorListener;
import org.apache.curator.framework.api.UnhandledErrorListener;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.framework.recipes.leader.LeaderLatch;
import org.apache.curator.framework.recipes.leader.LeaderLatchListener;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class Master implements LeaderLatchListener {
    private static final Logger LOG = LoggerFactory.getLogger(Master.class);
    private static final int FIVE_MINUTES = 5;
    private static final int SLEEP_MILLIS = 1000;
    private static final int TRY_TIMES = 30;

    private String myId;
    private CuratorFramework client;
    private final LeaderLatch leaderLatch;
    private final PathChildrenCache workersCache;
    private final PathChildrenCache tasksCache;
    private final PathChildrenCache statusCache;
    //Key: workerName, Value: count of the tasks which are assigned to this worker and not executed
    private final Map<String, AtomicInteger> workerAssignmentMap = new ConcurrentHashMap<>();

    private final ExecutorService guardianExecutor;
    private RecoveredAssignments.RecoveryCallback recoveryCallback = new MasterRecoveryCallback();
    private long guardianScanInterval = TimeUnit.MINUTES.toMillis(FIVE_MINUTES);

    /**
     * Creates a new Master.
     */
    public Master() {
        this.myId = ZKConstants.getHostName() + "_" + System.currentTimeMillis();
        LOG.info("myId: " + myId);
        this.client = CuratorClientFactory.create();
        this.leaderLatch = new LeaderLatch(this.client, ZKConstants.MASTER_PATH, myId);
        this.workersCache = new PathChildrenCache(this.client, ZKConstants.WORKERS_PATH, true);
        this.tasksCache = new PathChildrenCache(this.client, ZKConstants.TASKS_PATH, true);
        this.statusCache = new PathChildrenCache(this.client, ZKConstants.STATUS_PATH, true);

        guardianExecutor = Executors.newSingleThreadExecutor();
    }

    private void bootstrap() throws Exception {
        if (client.checkExists().forPath(ZKConstants.ZK_BASE_PATH) == null) {
            client.create().forPath(ZKConstants.ZK_BASE_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.WORKERS_PATH) == null) {
            client.create().forPath(ZKConstants.WORKERS_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.ASSIGN_PATH) == null) {
            client.create().forPath(ZKConstants.ASSIGN_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.TASKS_PATH) == null) {
            client.create().forPath(ZKConstants.TASKS_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.STATUS_PATH) == null) {
            client.create().forPath(ZKConstants.STATUS_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.BLOCKED_TASKS_PATH) == null) {
            client.create().forPath(ZKConstants.BLOCKED_TASKS_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.PAUSED_TASKS_PATH) == null) {
            client.create().forPath(ZKConstants.PAUSED_TASKS_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.COMMAND_PAUSE_PATH) == null) {
            client.create().creatingParentsIfNeeded().forPath(ZKConstants.COMMAND_PAUSE_PATH, new byte[0]);
        }
        if (client.checkExists().forPath(ZKConstants.COMMAND_CANCEL_PATH) == null) {
            client.create().creatingParentsIfNeeded().forPath(ZKConstants.COMMAND_CANCEL_PATH, new byte[0]);
        }
    }

    public void runForMaster() throws Exception {
        client.start();
        bootstrap();
        /*
         * Register listeners
         */
        client.getCuratorListenable().addListener(masterListener);
        client.getUnhandledErrorListenable().addListener(errorsListener);
        /*
         * Start master election
         */
        LOG.info("Starting master selection: " + myId);
        leaderLatch.addListener(this);
        leaderLatch.start();
    }

    /**
     * Waits until it becomes leader.
     */
    public void awaitLeadership() throws InterruptedException, EOFException {
        leaderLatch.await();
    }

    CountDownLatch recoveryLatch = new CountDownLatch(0);

    public boolean hasLeaderShip() {
        return leaderLatch.hasLeadership();
    }

    /**
     * Executed when client becomes leader.
     */
    @Override
    public void isLeader() {            
        /*
         * Start workersCache
         */
        try {
            workersCache.getListenable().addListener(workersCacheListener);
            workersCache.start(PathChildrenCache.StartMode.BUILD_INITIAL_CACHE);

            (new RecoveredAssignments(client.getZookeeperClient().getZooKeeper())).recover(recoveryCallback);
        } catch (Exception e) {
            LOG.error("Exception when starting leadership", e);
        }
    }

    @Override
    public void notLeader() {
        LOG.info("Lost leadership");
        try {
            close();
        } catch (IOException e) {
            LOG.warn("Exception while closing", e);
        }
        new Thread(new MasterRecover(TRY_TIMES, SLEEP_MILLIS)).start();
    }

    class MasterRecover implements Runnable {
        public MasterRecover(final int tryTimes, final long sleepMillis) {
            this.tryTimes = tryTimes;
            this.sleepMillis = sleepMillis;
        }

        private int tryTimes;
        private long sleepMillis;

        /**
         * When an object implementing interface <code>Runnable</code> is used
         * to create a thread, starting the thread causes the object's
         * <code>run</code> method to be called in that separately executing
         * thread.
         * <p>
         * The general contract of the method <code>run</code> is that it may
         * take any action whatsoever.
         *
         * @see Thread#run()
         */
        @Override
        public void run() {
            if (tryTimes > 0) {
                LOG.info("Trying to recover Master");
                try {
                    Thread.sleep(sleepMillis);
                } catch (InterruptedException e) {
                    LOG.error(e.getMessage(), e);
                }
                Master master = null;
                try {
                    master = new Master();
                    master.runForMaster();
                } catch (Exception e) {
                   LOG.error(e.getMessage(), e);
                   if (master != null) {
                       try {
                           master.close();
                       } catch (Exception e1) {
                           LOG.error(e1.getMessage(), e1);
                       }
                   }
                   if (--tryTimes > 0) {
                       new Thread(new MasterRecover(tryTimes, sleepMillis)).start();
                   }
                }
            }
        }
    }

    /*
     * We use one main listener for the master. The listener processes
     * callback and watch events from various calls we make. Note that
     * many of the events related to workers and tasks are processed
     * directly by the workers cache and the tasks cache.
     */
    CuratorListener masterListener = (client1, event) -> {
        LOG.info(String.format("MasterListener, Event path: %s, name %s, type:%s", event.getPath(), event.getName(), event.getType()));
        switch (event.getType()) {
            case CREATE:
                if (event.getPath().contains(ZKConstants.ASSIGN_PATH)) {
                    LOG.info("Task assigned correctly: " + event.getName());
                }
                break;
            default:
        }
    };

    PathChildrenCacheListener workersCacheListener = (client1, event) -> {
        if (event.getType() == PathChildrenCacheEvent.Type.CHILD_REMOVED) {
            try {
                String worker = event.getData().getPath().replaceFirst(ZKConstants.WORKERS_PATH + "/", "");
                LOG.info(worker + " lost!");
                workerAssignmentMap.remove(worker);
                getAbsentWorkerTasks(worker);
            } catch (Exception e) {
                LOG.error("Exception while trying to re-assign tasks", e);
            }
        }
    };

    private void getAbsentWorkerTasks(String worker) throws Exception {
        /*
         * Get assigned tasks
         */
        client.getChildren().inBackground((client1, event) -> {
            if (event.getResultCode() == KeeperException.Code.OK.intValue()) {

                /*
                 * Reassign the tasks.
                 */
                List<String> absentWorkerTasks = event.getChildren();
                LOG.info("absentWorkerTasks: " + absentWorkerTasks);
                if (absentWorkerTasks != null && !absentWorkerTasks.isEmpty()) {
                    reAssignTasks4AbsentWorker(absentWorkerTasks, worker);
                } else {
                    client1.delete().deletingChildrenIfNeeded().inBackground().forPath(ZKConstants.ASSIGN_PATH + "/" + worker);
                }
            } else if (event.getResultCode() == KeeperException.Code.NONODE.intValue()) {
                KeeperException exception = KeeperException.create(KeeperException.Code.get(event.getResultCode()), event.getPath());
                LOG.warn(exception.getMessage(), exception);
            } else {
                throw KeeperException.create(KeeperException.Code.get(event.getResultCode()), event.getPath());
            }
        }).forPath(ZKConstants.ASSIGN_PATH + "/" + worker);
    }

    void reAssignTasks4AbsentWorker(List<String> absentWorkerTasks, String worker) throws Exception {

        for (String task : absentWorkerTasks) {
            String statusPath = ZKConstants.STATUS_PATH + "/" + task;
            TaskStatus taskStatus = getTaskStatus(statusPath);

            if (taskStatus == null) {
                byte[] data;
                final String assignedPath = ZKConstants.ASSIGN_PATH + "/" + worker + "/" + task;
                try {
                    data = client.getData().forPath(assignedPath);
                } catch (KeeperException.NoNodeException e) {
                    LOG.warn(e.getMessage(), e);
                    continue;
                }
                try {
                    client.inTransaction().
                            create().withMode(CreateMode.PERSISTENT).forPath(ZKConstants.TASKS_PATH + "/" + task, data).
                            and().delete().forPath(assignedPath).and().commit();
                    LOG.info("{} moved to tasks!", assignedPath);
                } catch (KeeperException.NoNodeException | KeeperException.NodeExistsException e) {
                    LOG.debug(e.getMessage(), e);
                    LOG.warn(e.getMessage());
                }
            } else if (taskStatus.getStatus() == TaskExecutionStatus.STARTED) {
                taskStatus.setStatus(TaskExecutionStatus.INTERRUPTED);
                client.setData().forPath(statusPath, SerializationUtils.serialize(taskStatus));
                LOG.info("set {} to interrupted! ", task);
            }
        }
        client.delete().deletingChildrenIfNeeded().inBackground().forPath(ZKConstants.ASSIGN_PATH + "/" + worker);
    }

    private TaskStatus getTaskStatus(String taskPath) throws Exception {
        TaskStatus taskStatus = null;
        try {
            byte[] statusBytes = client.getData().forPath(taskPath);
            taskStatus = (TaskStatus) SerializationUtils.deserialize(statusBytes);
        } catch (KeeperException.NoNodeException e) {
            LOG.debug(e.getMessage(), e);
            LOG.warn(e.getMessage());
        }
        return taskStatus;
    }

    PathChildrenCacheListener tasksCacheListener = (client1, event) -> {
        if (event.getType() == PathChildrenCacheEvent.Type.CHILD_ADDED) {
            try {
                assignTask(event.getData().getPath().replaceFirst(ZKConstants.TASKS_PATH + "/", ""),
                        event.getData().getData());
            } catch (Exception e) {
                LOG.error("Exception when assigning task.", e);
            }
        }
    };

    PathChildrenCacheListener statusCacheListener = (client1, event) -> {
        if (event.getType() == PathChildrenCacheEvent.Type.CHILD_UPDATED) {
            TaskStatus taskStatus = (TaskStatus) SerializationUtils.deserialize(event.getData().getData());
            if (taskStatus.getStatus().isDone()) {
                String completedTask = event.getData().getPath().replaceFirst(ZKConstants.STATUS_PATH + "/", "");
                LOG.info(completedTask + " is completed with status " + taskStatus.getStatus());
                checkBlockedTasks(client1);
            }
            if (TaskExecutionStatus.STARTED != taskStatus.getStatus()) {
                AtomicInteger count = workerAssignmentMap.get(taskStatus.getUpdatedBy());
                if (count != null) {
                    count.getAndDecrement();
                }
            }
        }
    };

    private void checkBlockedTasks(final CuratorFramework client) throws Exception {
        client.getChildren().inBackground((curatorClient, event) -> {
            if (event.getResultCode() == KeeperException.Code.OK.intValue()) {
                List<String> blockedTasks = event.getChildren();
                LOG.info("blockedTasks: " + blockedTasks);
                if (blockedTasks != null && !blockedTasks.isEmpty()) {
                    for (String blockedTask : blockedTasks) {
                        checkBlockedTask(curatorClient, blockedTask);
                    }
                }
            } else {
                throw KeeperException.create(KeeperException.Code.get(event.getResultCode()), event.getPath());
            }
        }).forPath(ZKConstants.BLOCKED_TASKS_PATH);
    }

    private void checkBlockedTask(final CuratorFramework client, final String blockedTask) throws Exception {
        client.getData().inBackground((curatorClient, event) -> {
            if (event.getResultCode() == KeeperException.Code.OK.intValue()) {

                String blockedTaskPath = ZKConstants.TASKS_PATH + "/" + blockedTask;
                try {
                    client.inTransaction().
                            create().forPath(blockedTaskPath, event.getData()).
                            and().delete().forPath(ZKConstants.BLOCKED_TASKS_PATH + "/" + blockedTask).
                            and().commit();
                    LOG.info("{} moved to tasks", blockedTask);
                } catch (KeeperException.NodeExistsException e) {
                    LOG.debug(e.getMessage(), e);
                    LOG.warn(e.getMessage() + ": " + blockedTaskPath);
                }
            } else if (event.getResultCode() != KeeperException.Code.NONODE.intValue()) {
                throw KeeperException.create(KeeperException.Code.get(event.getResultCode()), event.getPath());
            }
        }).forPath(ZKConstants.BLOCKED_TASKS_PATH + "/" + blockedTask);
    }

    /*
     * Random variable we use to select a worker to perform a pending task.
     */
    Random rand = new Random(System.currentTimeMillis());

    void assignTasks(List<String> tasks) {
        for (String task : tasks) {
            byte[] taskData = null;
            try {
                taskData = client.getData().forPath(ZKConstants.TASKS_PATH + "/" + task);
            } catch (KeeperException.NoNodeException e) {
                LOG.debug(e.getMessage(), e);
                LOG.warn(e.getMessage());
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
            if (taskData != null) {
                try {
                    assignTask(task, taskData);
                } catch (Exception e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
    }

    private AtomicInteger assignedCount = new AtomicInteger(0);

    void assignTask(String task, byte[] data) throws Exception {
        /*
         * Choose worker at random.
         */
        List<ChildData> workersList = workersCache.getCurrentData();

        LOG.info("Assigning task {}", task);

        String designatedWorker = workersList.get(assignedCount.getAndIncrement() % workersList.size()).getPath()
                .replaceFirst(ZKConstants.WORKERS_PATH + "/", "");

        createAssignment(data, task, designatedWorker);
    }

    /**
     * Creates an assignment.
     *
     */
    void createAssignment(byte[] data, String task, String designatedWorker) throws Exception {
        String path = ZKConstants.ASSIGN_PATH + "/" + designatedWorker + "/" + task;
        try {
            client.inTransaction().
                    create().withMode(CreateMode.PERSISTENT).forPath(path, data).
                    and().delete().forPath(ZKConstants.TASKS_PATH + "/" + task).
                    and().commit();
            AtomicInteger count = workerAssignmentMap.computeIfAbsent(designatedWorker, k -> new AtomicInteger(0));
            count.getAndIncrement();

            LOG.info("Task assigned correctly: " + path);
        } catch (KeeperException.NodeExistsException | KeeperException.NoNodeException e) {
            LOG.debug(e.getMessage(), e);
            LOG.warn(e.getMessage());
        }
        recoveryLatch.countDown();
    }

    public void close() throws IOException {
        LOG.info("Closing! " + myId);
        leaderLatch.close();
        workersCache.close();
        tasksCache.close();
        statusCache.close();
        guardianExecutor.shutdown();
        client.close();

    }

    UnhandledErrorListener errorsListener = (message, e) -> LOG.error("Unrecoverable error: " + message, e);

    private class MasterRecoveryCallback implements RecoveredAssignments.RecoveryCallback {
        @Override
        public void recoveryComplete(final int rc, final List<String> tasks) {
            try {
                if (rc == RecoveredAssignments.RecoveryCallback.FAILED) {
                    LOG.warn("Recovery of assigned tasks failed. " + myId);
                } else {
                    LOG.info("Assigning recovered tasks: " + tasks + " " + myId);
                    recoveryLatch = new CountDownLatch(tasks.size());
                    Master.this.assignTasks(tasks);
                }
            } catch (Exception e) {
                LOG.error("Exception while executing the recovery callback", e);
            }
            try {
                recoveryLatch.await();
                tasksCache.getListenable().addListener(tasksCacheListener);
                tasksCache.start();
                statusCache.getListenable().addListener(statusCacheListener);
                statusCache.start();
                guardianExecutor.submit(guardian);

                LOG.info("zookeeper:add /task listener.");
            } catch (Exception e) {
                LOG.warn("Exception while assigning and getting tasks.", e);
            }
        }

        private Runnable guardian = () -> {
            LOG.info("Guardian process started! " + myId);
            while (hasLeaderShip()) {
                try (CuratorFramework clientA = CuratorClientFactory.create()) {
                    clientA.start();
                    List<String> blockedTasks = clientA.getChildren().forPath(ZKConstants.BLOCKED_TASKS_PATH);
                    LOG.info("blocked jobs: " + blockedTasks);
                    checkBlockedTasks4Guardian(clientA, blockedTasks);
                    Thread.sleep(guardianScanInterval);
                } catch (Exception e) {
                    LOG.error(e.getMessage(), e);
                }
            }

            LOG.info("Guardian process end! " + myId);
        };

        private void checkBlockedTasks4Guardian(CuratorFramework client, List<String> blockedTasks) throws Exception {
            for (String blockedTask : blockedTasks) {
                byte[] taskBytes;
                try {
                    taskBytes = client.getData().forPath(ZKConstants.BLOCKED_TASKS_PATH + "/" + blockedTask);
                } catch (KeeperException.NoNodeException e) {
                    //pending task may already be moved to task
                    LOG.debug(e.getMessage(), e);
                    LOG.warn(e.getMessage());
                    continue;
                }
                ZKTaskData taskData = (ZKTaskData) SerializationUtils.deserialize(taskBytes);
                LOG.info("blocked taskData: " + taskData);
                boolean blockerRunning = false;
                for (String blocker : taskData.getBlockedBy()) {
                    final ChildData blockerData = statusCache.getCurrentData(ZKConstants.STATUS_PATH + "/" + blocker);
                    if (blockerData != null) {
                        TaskStatus blockerTaskStatus = (TaskStatus) SerializationUtils.deserialize(blockerData.getData());
                        LOG.info("blockerData: path={}, taskStatus={}", blockerData.getPath(), blockerTaskStatus);
                        if (TaskExecutionStatus.STARTED == blockerTaskStatus.getStatus()) {
                            blockerRunning = true;
                            break;
                        }
                    }
                }

                if (!blockerRunning) {
                    LOG.info("No blocker! " + taskData);
                    try {
                        client.inTransaction().
                                create().forPath(ZKConstants.TASKS_PATH + "/" + blockedTask, taskBytes).
                                and().delete().forPath(ZKConstants.BLOCKED_TASKS_PATH + "/" + blockedTask).
                                and().commit();
                    } catch (KeeperException.NodeExistsException e) {
                        LOG.debug(e.getMessage(), e);
                        LOG.warn(e.getMessage());
                    }
                }
            }
        }
    }

    public void setGuardianScanInterval(final long guardianScanInterval) {
        this.guardianScanInterval = guardianScanInterval;
    }
}