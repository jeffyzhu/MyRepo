package com.lombardrisk.coordination.task.api;

import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Set;

public interface BackgroundTask extends Serializable {
    Logger LOG = LoggerFactory.getLogger(BackgroundTask.class);

    /**
     * gets the set of pessimistic permits that must be obtained before this task can run
     *
     * @return set of pessimistic permits
     */
    Set<PessimisticPermitType> getPessimisticPermitsRequired();

    String getTaskName();

    void execute();

    default void cancel() {
        LOG.info("{} is canceling.", getTaskName());
    }

    default void pause() {
        LOG.info("{} is pausing.", getTaskName());
    }
}
