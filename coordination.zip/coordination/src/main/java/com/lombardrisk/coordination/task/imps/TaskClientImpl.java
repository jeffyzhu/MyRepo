
package com.lombardrisk.coordination.task.imps;

import com.lombardrisk.coordination.CuratorClientFactory;
import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.exception.CoordinationException;
import com.lombardrisk.coordination.task.api.BackgroundTask;
import com.lombardrisk.coordination.task.api.TaskClient;
import com.lombardrisk.coordination.task.api.TaskResponse;
import com.lombardrisk.coordination.task.framework.TaskStatus;
import com.lombardrisk.coordination.task.framework.ZKTaskData;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.api.BackgroundCallback;
import org.apache.curator.framework.api.CuratorWatcher;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class TaskClientImpl implements TaskClient {
    private static final Logger LOG = LoggerFactory.getLogger(TaskClientImpl.class);

    private CuratorFramework client;
    private String principalName;

    public TaskClientImpl(String principalName) {
        client = CuratorClientFactory.create();
        client.start();
        this.principalName = principalName;
    }

    /*
     * Executes a task and watches for the result
    */
    @Override
    public TaskResponse submitTask(BackgroundTask task) throws CoordinationException {
        TaskResponseImpl taskCtx = new TaskResponseImpl();
        String taskName = task.getTaskName();
        if (taskName.contains("/")) {
            throw new IllegalArgumentException("Task name [" + taskName + "] cannot contain '/'!");
        }
        taskCtx.setTaskName(taskName);
        try {
            client.create().withMode(CreateMode.PERSISTENT).inBackground((clientA, event) -> {
                TaskResponseImpl taskResponse = (TaskResponseImpl) event.getContext();
                taskResponse.setTaskPath(event.getName());
                if (event.getResultCode() == Code.OK.intValue()) {
                    LOG.info("My created task name: " + event.getName());
                    watchStatus(event.getName().replace("/tasks/", "/status/"), (TaskResponseImpl) event.getContext(), statusWatcher);
                } else {
                    throw KeeperException.create(Code.get(event.getResultCode()), event.getPath());
                }
                taskResponse.submitted();
            }, taskCtx).forPath(ZKConstants.TASKS_PATH + "/" + taskName, SerializationUtils.serialize(new ZKTaskData(task, principalName)));
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
        return taskCtx;
    }

    @Override
    public TaskResponse checkTask(String taskName) throws CoordinationException {
        TaskResponseImpl taskCtx = new TaskResponseImpl();
        taskCtx.setTaskName(taskName);
        taskCtx.setTaskPath(ZKConstants.TASKS_PATH + "/" + taskName);
        taskCtx.submitted();//assume submitted when checking
        try {
            watchStatus(ZKConstants.STATUS_PATH + "/" + taskName, taskCtx, statusWatcher);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
        return taskCtx;
    }

    private ConcurrentHashMap<String, List<TaskResponseImpl>> ctxMap = new ConcurrentHashMap<>();

    void watchStatus(String path, TaskResponseImpl ctx, CuratorWatcher watcher) throws Exception {
        ctxMap.computeIfAbsent(path, k -> new ArrayList<>()).add(ctx);

        LOG.info("add watcher for path: " + path);
        client.checkExists().usingWatcher(watcher).inBackground((clientA, event) -> {
            if (event.getResultCode() == KeeperException.Code.OK.intValue()) {
                if (event.getStat() != null) {

                    clientA.getData().inBackground(getDataBKCallback, ctxMap.get(event.getPath())).forPath(event.getPath());
                    LOG.info("Status node is there: " + event.getPath());
                }
            } else if (event.getResultCode() != Code.NONODE.intValue()) {
                throw KeeperException.create(KeeperException.Code.get(event.getResultCode()), event.getPath());
            }
        }, ctx).forPath(path);
    }

    CuratorWatcher statusWatcher = new StatusWatcher();

    BackgroundCallback getDataBKCallback = (clientA, event) -> {
        if (event.getResultCode() == Code.OK.intValue()) {
            TaskStatus taskStatus = (TaskStatus) SerializationUtils.deserialize(event.getData());
            LOG.info("Task " + event.getPath() + ", " + taskStatus);
            if (taskStatus.getStatus().isEnd()) {
                LOG.info("Task {} End with status: {}", event.getPath(), taskStatus.getStatus());
                ((List<TaskResponseImpl>) event.getContext()).forEach(taskResponse -> taskResponse.setStatus(taskStatus.getStatus()));
                ctxMap.remove(event.getPath());
            }
        } else {
            LOG.info("Task Error: " + event);
            throw KeeperException.create(Code.get(event.getResultCode()), event.getPath());
        }
    };

    @Override
    public void close() throws IOException {
        LOG.info("Closing");
        client.close();
        ctxMap.clear();
    }

    private class StatusWatcher implements CuratorWatcher {
        public void process(WatchedEvent e) throws Exception {
            LOG.info("WatchedEvent: " + e);
            if (e.getType() == EventType.NodeDataChanged || e.getType() == EventType.NodeCreated) {
                assert e.getPath().contains("/status/");
                client.getData().usingWatcher(this).inBackground(getDataBKCallback, ctxMap.get(e.getPath())).forPath(e.getPath());
            }
        }
    }

    @Override
    public List<String> cancelAllTasks() throws CoordinationException {
        List<String> canceledTasks = new ArrayList<>();

        try {
            Set<String> tasks = getAllTasks();
            for (String task : tasks) {
                if (client.checkExists().forPath(ZKConstants.STATUS_PATH + "/" + task) != null) {
                    byte[] bytes = client.getData().forPath(ZKConstants.STATUS_PATH + "/" + task);
                    TaskStatus taskStatus = (TaskStatus) SerializationUtils.deserialize(bytes);
                    if (taskStatus.getStatus() == ZKConstants.TaskExecutionStatus.STARTED || taskStatus.getStatus().isDone()) {
                        LOG.warn(" {} is executing or already executed, so cannot be canceled!", task);
                        continue;
                    }
                }
                client.create().withMode(CreateMode.PERSISTENT).forPath(ZKConstants.COMMAND_CANCEL_PATH + "/" + task);
                LOG.info("Cancel command has been sent for {}", task);
                canceledTasks.add(task);
            }
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
        return canceledTasks;
    }

    @Override
    public List<String> pauseAllTasks() throws CoordinationException {
        List<String> pausedTasks = new ArrayList<>();
        try {
            Set<String> tasks = getAllTasks();
            for (String task : tasks) {
                if (client.checkExists().forPath(ZKConstants.STATUS_PATH + "/" + task) != null) {
                    byte[] bytes = client.getData().forPath(ZKConstants.STATUS_PATH + "/" + task);
                    TaskStatus taskStatus = (TaskStatus) SerializationUtils.deserialize(bytes);
                    if (taskStatus.getStatus() == ZKConstants.TaskExecutionStatus.STARTED || taskStatus.getStatus().isDone()) {
                        LOG.warn(" {} is executing or already executed, so cannot be paused!", task);
                        continue;
                    }
                }
                client.create().withMode(CreateMode.PERSISTENT).forPath(ZKConstants.COMMAND_PAUSE_PATH + "/" + task);
                LOG.info("Pause command has been sent for {}", task);
                pausedTasks.add(task);
            }
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
        return pausedTasks;
    }

    private Set<String> getAllTasks() throws Exception {
        Set<String> tasks = new HashSet<>();
        tasks.addAll(client.getChildren().forPath(ZKConstants.TASKS_PATH));
        tasks.addAll(client.getChildren().forPath(ZKConstants.BLOCKED_TASKS_PATH));

        List<String> workers = client.getChildren().forPath(ZKConstants.WORKERS_PATH);
        for (String worker : workers) {
            tasks.addAll(client.getChildren().forPath(ZKConstants.ASSIGN_PATH + "/" + worker));
        }
        return tasks;
    }

    @Override
    public void cancelTask(String taskName) throws CoordinationException {
        try {
            if (isTaskExisted(taskName)) {
                if (client.checkExists().forPath(ZKConstants.STATUS_PATH + "/" + taskName) != null) {
                    byte[] bytes = client.getData().forPath(ZKConstants.STATUS_PATH + "/" + taskName);
                    TaskStatus taskStatus = (TaskStatus) SerializationUtils.deserialize(bytes);
                    if (taskStatus.getStatus() == ZKConstants.TaskExecutionStatus.STARTED || taskStatus.getStatus().isDone()) {
                        LOG.warn(" {} is executing or already executed, so cannot be canceled!", taskName);
                        throw new CoordinationException(taskName + " is executing or already executed, so cannot be canceled!");
                    }
                }
                client.create().withMode(CreateMode.PERSISTENT).forPath(ZKConstants.COMMAND_CANCEL_PATH + "/" + taskName);
                LOG.info("Cancel command has been sent for {}", taskName);
            } else {
                LOG.warn(" {} is not existed, so cannot be canceled!", taskName);
                throw new CoordinationException(taskName + " is not existed, so cannot be canceled!");
            }
        } catch (RuntimeException | CoordinationException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
    }

    @Override
    public void pauseTask(String taskName) throws CoordinationException {
        try {
            if (isTaskExisted(taskName)) {
                if (client.checkExists().forPath(ZKConstants.STATUS_PATH + "/" + taskName) != null) {
                    byte[] bytes = client.getData().forPath(ZKConstants.STATUS_PATH + "/" + taskName);
                    TaskStatus taskStatus = (TaskStatus) SerializationUtils.deserialize(bytes);
                    if (taskStatus.getStatus() == ZKConstants.TaskExecutionStatus.STARTED || taskStatus.getStatus().isDone()) {
                        LOG.warn(" {} is executing or already executed, so cannot be paused!", taskName);
                        throw new CoordinationException(taskName + " is executing or already executed, so cannot be paused!");
                    }
                }
                client.create().withMode(CreateMode.PERSISTENT).forPath(ZKConstants.COMMAND_PAUSE_PATH + "/" + taskName);
                LOG.info("Pause command has been sent for {}", taskName);
            } else {
                LOG.warn(" {} is not existed, so cannot be paused!", taskName);
                throw new CoordinationException(taskName + " is not existed, so cannot be canceled!");
            }
        } catch (RuntimeException | CoordinationException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
    }

    @Override
    public List<String> resumeAllTasks() {
        Set<String> resumedTasks = new LinkedHashSet<>();
        List<String> commands = Collections.emptyList();
        try {
            commands = client.getChildren().forPath(ZKConstants.COMMAND_PAUSE_PATH);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }

        for (String command : commands) {
            try {
                cleanCommand(command);
                resumedTasks.add(command);
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
        }

        List<String> pausedTasks = Collections.emptyList();
        try {
            pausedTasks = client.getChildren().forPath(ZKConstants.PAUSED_TASKS_PATH);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
        for (String  pausedTask : pausedTasks) {
            try {
                moveBackPausedTask(pausedTask);
                resumedTasks.add(pausedTask);
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
        }

        return new ArrayList<>(resumedTasks);
    }

    @Override
    public void resumeTask(String taskName) throws CoordinationException {
        try {
            cleanCommand(taskName);

            moveBackPausedTask(taskName);
            LOG.info("{} has been resumed!", taskName);
        } catch (RuntimeException | CoordinationException e) {
            throw e;
        } catch (Exception e) {
            throw new CoordinationException(e);
        }
    }

    private void moveBackPausedTask(final String taskName) throws Exception {
        byte[] taskBytes = null;
        String pausedTaskPath = ZKConstants.PAUSED_TASKS_PATH + "/" + taskName;
        try {
            taskBytes = client.getData().forPath(pausedTaskPath);
        } catch (KeeperException.NoNodeException e) {
            LOG.warn(e.getMessage());
            LOG.debug(e.getMessage(), e);
        }
        if (taskBytes != null) {
            client.inTransaction().
                    create().forPath(ZKConstants.TASKS_PATH + "/" + taskName, taskBytes).
                    and().delete().forPath(pausedTaskPath).
                    and().commit();
        }
    }

    private void cleanCommand(final String taskName) throws Exception {
        String commandPath = ZKConstants.COMMAND_PAUSE_PATH + "/" + taskName;
        if (client.checkExists().forPath(commandPath) != null) {
            try {
                client.delete().forPath(commandPath);
            } catch (KeeperException.NoNodeException e) {
                LOG.warn(e.getMessage());
                LOG.debug(e.getMessage(), e);
            }
        }
    }

    private boolean isTaskExisted(final String taskName) {
        boolean taskExisted = false;
        try {
            taskExisted = client.checkExists().forPath(ZKConstants.TASKS_PATH + "/" + taskName) != null
                    || client.checkExists().forPath(ZKConstants.BLOCKED_TASKS_PATH + "/" + taskName) != null;
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }

        if (!taskExisted) {
            List<String> workers;
            try {
                workers = client.getChildren().forPath(ZKConstants.WORKERS_PATH);
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
                workers = Collections.emptyList();
            }
            for (String worker : workers) {
                try {
                    if (client.checkExists().forPath(ZKConstants.ASSIGN_PATH + "/" + worker + "/" + taskName) != null) {
                        taskExisted = true;
                        break;
                    }
                } catch (Exception e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return taskExisted;
    }
}
