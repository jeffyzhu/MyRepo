package com.lombardrisk.coordination.task.api;

public interface TaskResponse {
    String getTaskName();

    String getTaskPath();

    String getTaskStatus();

    void waitUntilSubmitted();

    void waitUntilEnd();

    boolean isEnd();
}
