package com.lombardrisk.coordination.task;

import com.lombardrisk.coordination.task.api.TaskClient;
import com.lombardrisk.coordination.task.framework.Master;
import com.lombardrisk.coordination.task.framework.Worker;
import com.lombardrisk.coordination.task.imps.TaskClientImpl;

public final class TaskUtil {
    private TaskUtil() {
    }

    public static TaskClient createTaskClient(String principalName) {
        return new TaskClientImpl(principalName);
    }

    public static void startMaster() throws Exception {
        Master master = new Master();
        master.runForMaster();
    }

    public static void startWorker() throws Exception {
        Worker worker = new Worker();
        worker.start();
    }
}
