package com.lombardrisk.coordination.task.framework;

import com.google.common.base.MoreObjects;
import com.lombardrisk.coordination.task.api.BackgroundTask;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;

public class ZKTaskData implements Serializable {
    private static final long serialVersionUID = -8180946860809547884L;
    private String taskName;
    private String callerPrincipal;
    private Set<String> blockedBy = Collections.emptySet();
    private BackgroundTask backgroundTask;

    public ZKTaskData(BackgroundTask backgroundTask, String callerPrincipal) {
        this.taskName = backgroundTask.getTaskName();
        this.backgroundTask = backgroundTask;
        this.callerPrincipal = callerPrincipal;
    }

    String getTaskName() {
        return taskName;
    }

    Set<String> getBlockedBy() {
        return blockedBy;
    }

    BackgroundTask getBackgroundTask() {
        return backgroundTask;
    }

    void setBlockedBy(Set<String> blockedBy) {
        this.blockedBy = blockedBy;
    }

    String getCallerPrincipal() {
        return callerPrincipal;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("taskName", taskName)
                .add("callerPrincipal", callerPrincipal)
                .add("blockedBy", blockedBy)
                .add("backgroundTask", backgroundTask)
                .toString();
    }
}
