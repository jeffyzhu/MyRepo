package com.lombardrisk.coordination.task.framework;

import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import com.lombardrisk.coordination.task.api.BackgroundTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Set;

public class TestTask implements BackgroundTask {
    private static final Logger LOG = LoggerFactory.getLogger(Master.class);
    private String taskName;
    private Set<PessimisticPermitType> requiredPermits = Collections.emptySet();
    private long sleepMillis = 20;

    public TestTask(String taskName, Set<PessimisticPermitType> requiredPermits) {
        this.taskName = taskName;
        this.requiredPermits = requiredPermits;
    }

    public TestTask(String taskName, Set<PessimisticPermitType> requiredPermits, long sleepMillis) {
        this.taskName = taskName;
        this.requiredPermits = requiredPermits;
        this.sleepMillis = sleepMillis;
    }

    /**
     * gets the set of pessimistic permits that must be obtained before this task can run
     *
     * @return set of pessimistic permits
     */
    @Override
    public Set<PessimisticPermitType> getPessimisticPermitsRequired() {
        return requiredPermits;
    }

    @Override
    public String getTaskName() {
        return taskName;
    }

    @Override
    public void execute() {
        try {
            LOG.info("executing TestTask: " + getTaskName());
            Thread.sleep(sleepMillis);
        } catch (InterruptedException e) {
            LOG.error(e.getMessage(), e);
        }
    }

}
