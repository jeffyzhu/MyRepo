package com.lombardrisk.coordination.task.framework;

import com.lombardrisk.coordination.CuratorClientFactory;
import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.ZookeeperTest;
import com.lombardrisk.coordination.permit.PermitsCenter;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import com.lombardrisk.coordination.task.api.TaskClient;
import com.lombardrisk.coordination.task.api.TaskResponse;
import com.lombardrisk.coordination.task.imps.TaskClientImpl;
import org.apache.curator.framework.CuratorFramework;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

public class MasterTest
        extends ZookeeperTest
{
    private static final Logger LOG = LoggerFactory.getLogger(MasterTest.class);

    @Test(timeout = 5000)
    @Ignore
    public void electMaster() throws Exception {
        Master m = new Master();
        m.runForMaster();
        m.awaitLeadership();
        assertThat(m.hasLeaderShip()).isTrue();
        Thread.sleep(200);
        m.close();
    }

    @Test(timeout = 5000)
    @Ignore
    public void electSingleMaster() throws Exception {
        Master m = new Master();
        Master bm = new Master();

        bm.runForMaster();
        m.runForMaster();

        while (!m.hasLeaderShip() && !bm.hasLeaderShip()) {
            System.out.println("m: " + m.hasLeaderShip() + ", bm: " + bm.hasLeaderShip());
            Thread.sleep(200);
        }

        boolean singleMaster = m.hasLeaderShip() ^ bm.hasLeaderShip();
        System.out.println("m: " + m.hasLeaderShip() + ", bm: " + bm.hasLeaderShip());
        assertThat(singleMaster).isTrue();
        Thread.sleep(200);
        m.close();
        bm.close();
    }

    @Test(timeout = 5000)
    @Ignore
    public void reElectMaster() throws Exception {
        Master m = new Master();
        Master bm = new Master();

        bm.runForMaster();
        m.runForMaster();

        while (!m.hasLeaderShip() && !bm.hasLeaderShip()) {
            Thread.sleep(200);
        }
        System.out.println("m: " + m.hasLeaderShip() + ", bm: " + bm.hasLeaderShip());
        boolean singleMaster = m.hasLeaderShip() ^ bm.hasLeaderShip();
        assertThat(singleMaster).isTrue();

        Master mLeader = m.hasLeaderShip() ? m : bm;
        Master mNotLeader = m.hasLeaderShip() ? bm : m;
        Thread.sleep(200);
        mLeader.close();
        mNotLeader.awaitLeadership();
        assertThat(mNotLeader.hasLeaderShip()).isTrue();
        Thread.sleep(200);
        mNotLeader.close();
    }

    @Test(timeout = 90000)
    @Ignore
    public void testTaskAssignmentLatch() throws Exception {

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        Master m = new Master();
        m.runForMaster();

        m.awaitLeadership();

        TaskClient c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, Collections.emptySet()));
            tasks.add(taskResponse);
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount).isEqualTo(99);
        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    @Test(timeout = 90000)
    @Ignore
    public void testMasterFailover() throws Exception {
        Master m = new Master();
        m.runForMaster();

        m.awaitLeadership();
        Master bm = new Master();
        bm.runForMaster();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, Collections.emptySet()));
            tasks.add(taskResponse);
            if (i == 50) {
                m.close();
            }
        }
        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount).isEqualTo(99);
        clearStatus(tasks);
        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        bm.close();
        c.close();
    }

    @Test(timeout = 90000)
    @Ignore
    public void testWorkerFailover() throws Exception {
        Master m = new Master();
        m.runForMaster();

        m.awaitLeadership();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);
        Worker w4 = new TestWorker(4);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, Collections.emptySet()));
            tasks.add(taskResponse);

            if (i == 50) {
                w1.close();
                w4.start();
            }
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount).isEqualTo(99);
        clearStatus(tasks);
        w4.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    @Test(timeout = 90000)
    @Ignore
    public void testMasterAndWorkerFailover() throws Exception {
        Master m = new Master();
        m.runForMaster();

        m.awaitLeadership();
        Master bm = new Master();
        bm.runForMaster();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);
        Worker w4 = new TestWorker(4);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, Collections.emptySet()));
            tasks.add(taskResponse);
            if (i == 30) {
                m.close();
            }

            if (i == 70) {
                w1.close();
                w4.start();
            }
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount).isEqualTo(99);
        clearStatus(tasks);
        w4.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        bm.close();
        c.close();
    }

    @Test(timeout = 90000)
    @Ignore
    public void testWorkerAndMasterFailover() throws Exception {
        Master m = new Master();
        m.runForMaster();

        m.awaitLeadership();
        Master bm = new Master();
        bm.runForMaster();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);
        Worker w4 = new TestWorker(4);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, Collections.emptySet()));
            tasks.add(taskResponse);
            if (i == 30) {
                w1.close();
                w4.start();
            }

            if (i == 70) {
                m.close();
            }
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount).isEqualTo(99);
        clearStatus(tasks);
        w4.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        bm.close();
        c.close();
    }

    @Test(timeout = 150000)
    @Ignore
    public void testFeedTaskAssignment() throws Exception {
        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        int initBlockedCount = Worker.getBlockedCount().get();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));
        permits.add(PermitsCenter.defineWritePermitType("TestPermitB"));
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, permits));
            tasks.add(taskResponse);
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount - (Worker.getBlockedCount().get() - initBlockedCount)).isEqualTo(99);
        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    @Test(timeout = 150000)
    @Ignore
    public void testFeedMasterAndWorkerFailover() throws Exception {
        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();
        Master bm = new Master();
        bm.setGuardianScanInterval(2000);
        bm.runForMaster();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);
        Worker w4 = new TestWorker(4);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        int initBlockedCount = Worker.getBlockedCount().get();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, permits));
            tasks.add(taskResponse);

            if (i == 30) {
                m.close();
            }

            if (i == 70) {
                w1.close();
                w4.start();
            }
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount - (Worker.getBlockedCount().get() - initBlockedCount)).isEqualTo(99);
        clearStatus(tasks);
        w4.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        bm.close();
        c.close();
    }

    @Test(timeout = 150000)
    @Ignore
    public void testFeedWorkerAndMasterFailover() throws Exception {
        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();
        Master bm = new Master();
        bm.setGuardianScanInterval(2000);
        bm.runForMaster();

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);
        Worker w4 = new TestWorker(4);

        w1.start();
        w2.start();
        w3.start();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        int initBlockedCount = Worker.getBlockedCount().get();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));
        for (int i = 1; i < 100; i++) {
            TaskResponse taskResponse = c.submitTask(new TestTask("Test_Task_" + i, permits));
            tasks.add(taskResponse);
            if (i == 30) {
                w1.close();
                w4.start();
            }

            if (i == 70) {
                m.close();
            }
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount - (Worker.getBlockedCount().get() - initBlockedCount)).isEqualTo(99);
        clearStatus(tasks);
        w4.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        bm.close();
        c.close();
    }

    private void clearStatus(TaskResponse task, CuratorFramework curatorFramework) {
        try {
            curatorFramework.delete().forPath(ZKConstants.STATUS_PATH + "/" + task.getTaskName());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private void clearStatus(Collection<TaskResponse> tasks) {
        CuratorFramework curatorFramework = CuratorClientFactory.create();
        curatorFramework.start();
        try {
            curatorFramework.blockUntilConnected();
        } catch (InterruptedException e) {
            LOG.error(e.getMessage(), e);
        }
        tasks.forEach(taskResponse -> clearStatus(taskResponse, curatorFramework));
        curatorFramework.close();
    }

    @Test(timeout = 90000)
    @Ignore
    public void testTaskAssignmentLatch2() throws Exception {

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        Master m = new Master();
        m.runForMaster();

        m.awaitLeadership();

        TaskClient c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        int initCount = Worker.getExecutionCount().get();
        for (int i = 1; i < 100; i++) {
            TestTask task = new TestTask("Test_Task_" + i, Collections.emptySet());
            TaskResponse taskResponse = c.submitTask(task);
            tasks.add(c.checkTask(task.getTaskName()));
        }

        for (TaskResponse ta : tasks) {
            ta.waitUntilEnd();
            assertThat(ta.isEnd()).isTrue();
        }
        assertThat(Worker.getExecutionCount().get() - initCount).isEqualTo(99);
        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }
}
