package com.lombardrisk.coordination.permit;

import com.lombardrisk.coordination.ZookeeperTest;
import com.lombardrisk.coordination.permit.api.PessimisticPermit;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import com.lombardrisk.coordination.permit.imps.PessimisticLock;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

public class PessimisticLockTest extends ZookeeperTest {

    @Test
    public void acquireLock_WrongPath_ThrowIllegalArgumentException() throws Exception {
        assertThatIllegalArgumentException().isThrownBy(() -> {
            new PessimisticLock("testLock", "userA").acquireLock();
        });
    }

    @Test
    public void acquireLock_OneParticipant_AcquiredSuccessfully() throws Exception {
        PessimisticPermit pessimisticPermit = new PessimisticLock("/testLock", "userA").acquireLock();
        pessimisticPermit.release();
        assertThat(pessimisticPermit.isAcquired()).isTrue();
        assertThat(pessimisticPermit.getOwner()).isEqualTo("userA");
    }

    @Test
    public void acquireLock_DifferentPaths_AcquiredSuccessfully() throws Exception {
        PessimisticPermit pessimisticPermitA = new PessimisticLock("/testLockA", "userA").acquireLock();

        PessimisticPermit pessimisticPermitB = new PessimisticLock("/testLockB", "userB").acquireLock();
        pessimisticPermitA.release();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isTrue();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userB");
    }

    @Test
    public void acquireLock_TwoParticipants_SecondFailToAcquire() throws Exception {
        PessimisticPermit pessimisticPermitA = new PessimisticLock("/testLock", "userA").acquireLock();

        PessimisticPermit pessimisticPermitB = new PessimisticLock("/testLock", "userB").acquireLock();
        pessimisticPermitA.release();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isFalse();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userA");
    }

    @Test
    public void acquireLock_AcquireAfterRelease_AcquiredSuccessfully() throws Exception {
        PessimisticPermit pessimisticPermitA = new PessimisticLock("/testLock", "userA").acquireLock();
        pessimisticPermitA.release();
        PessimisticPermit pessimisticPermitB = new PessimisticLock("/testLock", "userB").acquireLock();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isTrue();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userB");
    }

    @Test
    public void queryLock_lockNotAcquired_NotAcquired() throws Exception {
        PessimisticPermit queryState = new PessimisticLock("/testLock", "userA").queryLock();
        queryState.release();
        assertThat(queryState.isAcquired()).isFalse();
        assertThat(queryState.getOwner()).isEqualTo("");
    }

    @Test
    public void queryLock_lockAcquired_Acquired() throws Exception {
        PessimisticPermit pessimisticPermit = new PessimisticLock("/testLock", "userA").acquireLock();
        PessimisticPermit queryState = new PessimisticLock("/testLock", "userB").queryLock();
        pessimisticPermit.release();
        queryState.release();
        assertThat(queryState.isAcquired()).isTrue();
        assertThat(queryState.getOwner()).isEqualTo("userA");
    }

    @Test
    public void queryLock_lockAcquiredByItself_Acquired() throws Exception {
        PessimisticLock lock = new PessimisticLock("/testLock", "userA");
        PessimisticPermit pessimisticPermitState = lock.acquireLock();
        PessimisticPermit queryState = lock.queryLock();
        pessimisticPermitState.release();
        queryState.release();
        assertThat(queryState.isAcquired()).isTrue();
        assertThat(queryState.getOwner()).isEqualTo("userA");
    }

    @Test
    public void acquireLock_MultiThreads_OwnerNotEmptyWhenFail() throws Exception {
        ExecutorService executorService = Executors.newFixedThreadPool(4);
        Future futureA = executorService.submit(new LockAcquireTask("/testLock", 100, "userA", 50));
        Future futureB = executorService.submit(new LockAcquireTask("/testLock", 100, "userB", 50));
        Future futureC = executorService.submit(new LockAcquireTask("/testLock", 100, "userC", 50));
        Future futureD = executorService.submit(new LockAcquireTask("/testLock", 100, "userD", 50));
        futureA.get();
        futureB.get();
        futureC.get();
        futureD.get();
    }

    private class LockAcquireTask implements Callable<List<PessimisticPermit>> {
        String lockPath;
        int acquireTimes;
        String participant;
        long sleepMills;

        LockAcquireTask(final String lockPath, final int acquireTimes, final String participant, final long sleepMills) {
            this.lockPath = lockPath;
            this.acquireTimes = acquireTimes;
            this.participant = participant;
            this.sleepMills = sleepMills;
        }

        /**
         * Computes a result, or throws an exception if unable to do so.
         *
         * @return computed result
         * @throws Exception if unable to compute a result
         */
        @Override
        public List<PessimisticPermit> call() throws Exception {
            List<PessimisticPermit> pessimisticPermits = new ArrayList<>();
            for (int i = 0; i < acquireTimes; i++) {
                PessimisticPermit pessimisticPermit = new PessimisticLock(lockPath, participant).acquireLock();
                if (pessimisticPermit.isAcquired()) {
                    Thread.sleep(sleepMills);
                    assertThat(pessimisticPermit.isAcquired()).isTrue();
                    assertThat(pessimisticPermit.getOwner()).isEqualTo(participant);
                } else {
                    assertThat(pessimisticPermit.isAcquired()).isFalse();
                    assertThat(pessimisticPermit.getOwner()).isNotEmpty().isNotEqualTo(participant);
                }
                pessimisticPermit.release();
                pessimisticPermits.add(pessimisticPermit);
            }
            return pessimisticPermits;
        }
    }

    @Test
    public void acquireReadLock_TwoParticipants_AcquiredSuccessfully() throws Exception {
        PessimisticPermit pessimisticPermitA =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.READ),"userA");

        PessimisticPermit pessimisticPermitB =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.READ),"userB");

        pessimisticPermitA.release();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isTrue();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userB");
    }

    @Test
    public void acquireWriteLock_TwoParticipants_SecondFail() throws Exception {
        PessimisticPermit pessimisticPermitA =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.WRITE),"userA");

        PessimisticPermit pessimisticPermitB =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.WRITE),"userB");

        pessimisticPermitA.release();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isFalse();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userA");
    }

    @Test
    public void acquireReadLock_WriteLock_WriteFailToAcquire() throws Exception {
        PessimisticPermit pessimisticPermitA =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.READ),"userA");

        PessimisticPermit pessimisticPermitB =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.WRITE),"userB");

        pessimisticPermitA.release();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isFalse();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userA");
    }

    @Test
    public void acquireWriteLock_ReadLock_ReadFailToAcquire() throws Exception {
        PessimisticPermit pessimisticPermitA =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.WRITE),"userA");

        PessimisticPermit pessimisticPermitB =
                PermitsCenter.applyPermit(PermitsCenter.definePermitType("testLock", PessimisticPermitType.Mode.READ),"userB");

        pessimisticPermitA.release();
        pessimisticPermitB.release();

        assertThat(pessimisticPermitA.isAcquired()).isTrue();
        assertThat(pessimisticPermitA.getOwner()).isEqualTo("userA");
        assertThat(pessimisticPermitB.isAcquired()).isFalse();
        assertThat(pessimisticPermitB.getOwner()).isEqualTo("userA");
    }
}