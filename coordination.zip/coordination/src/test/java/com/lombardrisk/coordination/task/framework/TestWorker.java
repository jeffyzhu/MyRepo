package com.lombardrisk.coordination.task.framework;

public class TestWorker extends Worker {
    private int testWorkerId;
    public TestWorker(int testWorkerId) {
        this.testWorkerId = testWorkerId;
    }

    protected String generateWorkerId() {
        return testWorkerId + "";
    }
}
