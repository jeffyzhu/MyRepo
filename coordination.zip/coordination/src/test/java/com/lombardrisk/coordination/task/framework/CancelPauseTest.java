package com.lombardrisk.coordination.task.framework;

import com.lombardrisk.coordination.CuratorClientFactory;
import com.lombardrisk.coordination.ZKConstants;
import com.lombardrisk.coordination.ZookeeperTest;
import com.lombardrisk.coordination.permit.PermitsCenter;
import com.lombardrisk.coordination.permit.api.PessimisticPermitType;
import com.lombardrisk.coordination.task.api.TaskResponse;
import com.lombardrisk.coordination.task.imps.TaskClientImpl;
import org.apache.curator.framework.CuratorFramework;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

public class CancelPauseTest
            extends ZookeeperTest
{
    private static final Logger LOG = LoggerFactory.getLogger(CancelPauseTest.class);

    @Ignore
    @Test(timeout = 50000)
    public void testCancelTask() throws Exception {

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));

        TaskResponse taskResponseA = c.submitTask(new TestTask("Test_Task_A", permits, 2000));
        tasks.add(taskResponseA);
        taskResponseA.waitUntilSubmitted();
        Thread.sleep(200);
        TaskResponse taskResponseB = c.submitTask(new TestTask("Test_Task_B", permits, 1000));
        tasks.add(taskResponseB);
        taskResponseB.waitUntilSubmitted();
        Thread.sleep(500);

        c.cancelTask("Test_Task_B");
        taskResponseA.waitUntilEnd();
        assertThat(taskResponseA.getTaskStatus()).isEqualTo("COMPLETED");

        taskResponseB.waitUntilEnd();
        assertThat(taskResponseB.getTaskStatus()).isEqualTo("CANCELED");

        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    @Ignore
    @Test(timeout = 50000)
    public void testCancelAll() throws Exception {

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));

        TaskResponse taskResponseA = c.submitTask(new TestTask("Test_Task_A", permits, 2000));
        tasks.add(taskResponseA);
        taskResponseA.waitUntilSubmitted();
        Thread.sleep(200);
        TaskResponse taskResponseB = c.submitTask(new TestTask("Test_Task_B", permits, 1000));
        tasks.add(taskResponseB);
        TaskResponse taskResponseC = c.submitTask(new TestTask("Test_Task_C", permits, 1000));
        tasks.add(taskResponseC);
        taskResponseB.waitUntilSubmitted();
        taskResponseC.waitUntilSubmitted();
        Thread.sleep(500);

        List<String> canceledTasks = c.cancelAllTasks();
        assertThat(canceledTasks.size()).isEqualTo(2);
        assertThat(canceledTasks.contains("Test_Task_B")).isTrue();
        assertThat(canceledTasks.contains("Test_Task_C")).isTrue();
        taskResponseA.waitUntilEnd();
        assertThat(taskResponseA.getTaskStatus()).isEqualTo("COMPLETED");

        taskResponseB.waitUntilEnd();
        assertThat(taskResponseB.getTaskStatus()).isEqualTo("CANCELED");
        taskResponseC.waitUntilEnd();
        assertThat(taskResponseC.getTaskStatus()).isEqualTo("CANCELED");

        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    @Ignore
    @Test(timeout = 50000)
    public void testPauseResumeTask() throws Exception {

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));

        TaskResponse taskResponseA = c.submitTask(new TestTask("Test_Task_A", permits, 2000));
        tasks.add(taskResponseA);
        taskResponseA.waitUntilSubmitted();
        Thread.sleep(200);
        TaskResponse taskResponseB = c.submitTask(new TestTask("Test_Task_B", permits, 1000));
        tasks.add(taskResponseB);
        taskResponseB.waitUntilSubmitted();
        Thread.sleep(500);

        c.pauseTask("Test_Task_B");
        taskResponseA.waitUntilEnd();
        assertThat(taskResponseA.getTaskStatus()).isEqualTo("COMPLETED");

        taskResponseB.waitUntilEnd();
        assertThat(taskResponseB.getTaskStatus()).isEqualTo("PAUSED");

        c.resumeTask("Test_Task_B");
        Thread.sleep(300);
        taskResponseB = c.checkTask("Test_Task_B");
        taskResponseB.waitUntilEnd();
        assertThat(taskResponseB.getTaskStatus()).isEqualTo("COMPLETED");

        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    @Ignore
    @Test(timeout = 50000)
    public void testPauseResumeAll() throws Exception {

        Worker w1 = new TestWorker(1);
        Worker w2 = new TestWorker(2);
        Worker w3 = new TestWorker(3);

        w1.start();
        w2.start();
        w3.start();

        Master m = new Master();
        m.setGuardianScanInterval(2000);
        m.runForMaster();

        m.awaitLeadership();

        TaskClientImpl c = new TaskClientImpl("userA");

        List<TaskResponse> tasks = new ArrayList<>();
        Set<PessimisticPermitType> permits = new HashSet<>();
        permits.add(PermitsCenter.defineWritePermitType("TestPermitA"));

        TaskResponse taskResponseA = c.submitTask(new TestTask("Test_Task_A", permits, 2000));
        tasks.add(taskResponseA);
        taskResponseA.waitUntilSubmitted();
        Thread.sleep(200);
        TaskResponse taskResponseB = c.submitTask(new TestTask("Test_Task_B", permits, 1000));
        tasks.add(taskResponseB);
        TaskResponse taskResponseC = c.submitTask(new TestTask("Test_Task_C", permits, 1000));
        tasks.add(taskResponseC);
        taskResponseB.waitUntilSubmitted();
        taskResponseC.waitUntilSubmitted();
        Thread.sleep(500);

        List<String> pausedTasks = c.pauseAllTasks();
        assertThat(pausedTasks.size()).isEqualTo(2);
        assertThat(pausedTasks.contains("Test_Task_B")).isTrue();
        assertThat(pausedTasks.contains("Test_Task_C")).isTrue();
        taskResponseA.waitUntilEnd();
        assertThat(taskResponseA.getTaskStatus()).isEqualTo("COMPLETED");

        taskResponseB.waitUntilEnd();
        assertThat(taskResponseB.getTaskStatus()).isEqualTo("PAUSED");
        taskResponseC.waitUntilEnd();
        assertThat(taskResponseC.getTaskStatus()).isEqualTo("PAUSED");

        List<String> resumedTasks = c.resumeAllTasks();
        assertThat(resumedTasks.size()).isEqualTo(2);
        assertThat(resumedTasks.contains("Test_Task_B")).isTrue();
        assertThat(resumedTasks.contains("Test_Task_C")).isTrue();
        Thread.sleep(300);
        taskResponseB = c.checkTask("Test_Task_B");
        taskResponseB.waitUntilEnd();
        assertThat(taskResponseB.getTaskStatus()).isEqualTo("COMPLETED");
        taskResponseC = c.checkTask("Test_Task_C");
        taskResponseC.waitUntilEnd();
        assertThat(taskResponseC.getTaskStatus()).isEqualTo("COMPLETED");

        clearStatus(tasks);

        w1.close();
        w2.close();
        w3.close();
        Thread.sleep(200);
        m.close();
        c.close();
    }

    private void clearStatus(TaskResponse task, CuratorFramework curatorFramework) {
        try {
            curatorFramework.delete().forPath(ZKConstants.STATUS_PATH + "/" + task.getTaskName());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private void clearStatus(Collection<TaskResponse> tasks) {
        CuratorFramework curatorFramework = CuratorClientFactory.create();
        curatorFramework.start();
        try {
            curatorFramework.blockUntilConnected();
        } catch (InterruptedException e) {
            LOG.error(e.getMessage(), e);
        }
        tasks.forEach(taskResponse -> clearStatus(taskResponse, curatorFramework));
        curatorFramework.close();
    }
}
