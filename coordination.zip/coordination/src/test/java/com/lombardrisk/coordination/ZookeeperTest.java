package com.lombardrisk.coordination;

import org.apache.curator.test.TestingServer;
import org.junit.AfterClass;
import org.junit.BeforeClass;

public class ZookeeperTest {
    protected static TestingServer server = null;

    private static int subClassRun = 0;

    @BeforeClass
    public static void setUp() throws Exception {
        if (server == null) {
            server = new TestingServer();
            server.start();
            System.out.println("connection string: " + server.getConnectString());
            System.setProperty(CuratorClientFactory.ZOOKEEPER_CONNECT_STRING, server.getConnectString());
        }
    }

    @AfterClass
    public static void tearDown() throws Exception {
        subClassRun++;
        if (subClassRun >= 3) {
            server.close();
            server = null;
        }
//        server.close();
    }
}
