# Colline coordination

Based on zookeeper, include two parts:
###1)  Pessimistic read/write permit
A read/write mutex that works across JVMs. Uses Zookeeper to hold the lock.
 All processes in all JVMs that use the same lock path will achieve an inter-process critical section. 
#### Usage
##### Use `PermitsCenter` to Define a permit type
```Java
public static PessimisticPermitType definePermitType(String name, String grainIdentifier, Mode mode, int priority)

Parameters:
name - permit type name
grainIdentifier - grain identifier of the permit, such as agreementId, eventId
mode - read or write
priority - when acquiring several permits at same time, permit with lower priority will be applied first
```
##### Use `PermitsCenter` to apply a permit
```java
public static PessimisticPermit applyPermit(PessimisticPermitType type, String applicant)

Parameters:
type - permit type
applicant - applicant
```
###2)  Master-worker system
There is a primary master assigning tasks and it supports backup masters to replace the primary in the case it crashes. 
Workers execute tasks assigned to it. If the task cannot get the permits to run, it will be set to blocked and will apply required permits again 
when other tasks completed. Finally, clients submit tasks and wait for a status znode.
#### Usage
##### Define a task implements `BackgroundTask`
```java
public interface BackgroundTask extends Serializable {

    /**
     * gets the set of pessimistic permits that must be obtained before this task can run
     *
     * @return set of pessimistic permits
     */
    Set<PessimisticPermitType> getPessimisticPermitsRequired();

    String getTaskName();

    void execute();
}
```
##### Use `TaskClient` to submit a task
```java
TaskResponse submitTask(BackgroundTask task) throws Exception

Parameters:
task - defined task
Returns:
TaskResponse
Throws:
Exception - exception when submitting the task
```

